#pragma once
template <class T>
class Stack
{

	protected:
		T* arr;
		int maxsize;
		int currentsize;
	public:
		virtual void addElement(T) = 0;
		virtual T removeElement() = 0;
		/*void regrow(T s)
		{
			T* oldarr = new T[currentsize];
			for (int i = 0; i < currentsize; i++)
			{
				oldarr[i] = arr[i];
			}

			arr = new T[currentsize + 1];
			for (int i = 0; i < currentsize; i++)
			{
				Stack<T>::arr[i] = oldarr[i];
			}
			arr[currentsize] = s;
			currentsize++;
		}*/
		Stack(int s)
		{
			maxsize = s;
			arr = new T[maxsize];
			
			currentsize = 0;
		}
		Stack(const Stack &obj)
		{
			maxsize = Stack<T>:: obj.maxsize;
			currentsize = Stack<T>::obj.currentsize;
			arr = new T[maxsize];
			for (int i = 0; i < Stack<T>::currentsize; i++)
			{
				arr[i] = Stack<T>::obj.arr[i];
			}
		}

		virtual ~Stack()
		{
			delete[]arr;
			arr = nullptr;
		}

};

