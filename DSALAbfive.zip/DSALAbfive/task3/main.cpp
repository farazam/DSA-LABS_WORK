#include<iostream>
#include"myStack.h"
#include"Queue.h"
using namespace std;
template <class T>
void showQueue(Queue<T>& obj);
template <class T>
void ShowStack(myStack <T>& obj);

int main()
{
	int remainder;
	int num1, num2;
	int reversedNumber=0;
	Queue<int> obj;
	Queue<int> obj1;
	cout << "\nEnter 1st 10 Digit Number :";
	cin >> num1;
	cout << "\nEnter second 10 Digit Number :";
	cin >> num2;

	while (num1 != 0)
	{
		remainder = num1 % 10;
		obj.enqueue(remainder);
		reversedNumber = reversedNumber * 10 + remainder;
		num1 /= 10;
	}
	while (num2 != 0)
	{
		remainder = num2 % 10;
		obj1.enqueue(remainder);
		reversedNumber = reversedNumber * 10 + remainder;
		num2 /= 10;
	}

	myStack<int> s_obj(15);
	int quo = 0;
	int sum=0;
	while (!obj.empty() && !obj1.empty())
	{
		sum = sum + obj.Dequeue();
		sum = sum + obj1.Dequeue();
		quo = sum / 10;
		remainder = sum % 10;
		s_obj.addElement(remainder);
		sum = 0;
		sum = sum + quo;
		
	}
	myStack<int> s_obj1(15);
	
	int size = s_obj.size();
	for(int i = 0; i < size; i++)
	{
		int t = s_obj.removeElement();
		s_obj1.addElement(t);
	}
	int*ptr=s_obj1.getarr();
	cout << "\nSum of Two numbers is :";
	ShowStack(s_obj1);
	
	
	
}

template <class T>
void showQueue(Queue<T>& obj)
{

	if (!obj.empty())
	{
		cout << "\nQueue is :\n";
		T* ptr = obj.getarr();
		for (int i = 0; i < obj.size(); i++)
		{
			cout << ptr[i];
		}
	}
	else
	{
		cout << "\nQueue is Empty\n";
	}
}

template <class T>
void ShowStack(myStack <T>& obj)
{
	T* localtemp = obj.getarr();
	if (!obj.isempty())
	{
		for (int i = 0; i < obj.size(); i++)
		{

			cout << localtemp[i];
		}
	}
	else
	{
		cout << "\nStack is empty\n";
	}
}