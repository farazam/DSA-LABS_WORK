#include<iostream>
#include"Queue.h"
using namespace std;
template <class T>
void showQueue(Queue<T>& obj)
{
	
	if (!obj.empty())
	{
		cout << "\nQueue is :\n";
		T* ptr = obj.getarr();
		for (int i = 0; i < obj.size(); i++)
		{
			cout<<i<<". " << ptr[i] << endl;
		}
	}
	else
	{
		cout << "\nQueue is Empty\n";
	}
}
int main()
{
	Queue<int> obj;
	obj.enqueue(110);
	obj.enqueue(14);
	obj.enqueue(190);
	obj.enqueue(34);
	obj.enqueue(54);
	showQueue(obj);
	obj.enqueue(14);
	obj.Dequeue();
	obj.Dequeue();
	obj.Dequeue();
	obj.Dequeue();
	showQueue(obj);
	obj.Dequeue();
	showQueue(obj);
	
	
}