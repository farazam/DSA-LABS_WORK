#include<iostream>
#include"List.h"
#include"MyList.h"
using namespace std;
void showList(MyList& obj);

int main()
{

	MyList obj(5);

	obj.addElement(6);
	obj.addElement(9);
	obj.addElement(8);
	obj.addElement(7);
	obj.addElement(5);
	
	
	showList(obj);
	obj.sortAscending();
	obj.display();
}
void showList(MyList& obj)
{
	int* localtemp = obj.getarr();
	if (!obj.empty())
	{
		cout << "\nStack :\n";
		for (int i = 0; i < obj.size(); i++)
		{

			cout << localtemp[i] << endl;
		}
	}
	else
	{
		cout << "\nStack is empty\n";
	}
}