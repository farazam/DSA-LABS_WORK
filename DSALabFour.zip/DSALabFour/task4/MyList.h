#pragma once
#include"List.h"
class MyList: public List
{
public:
	void addElement(int) ;
	 int removeElement();
	 bool empty();
	 bool full();
	 int size();
	 int last();
	 MyList(int s = 0);
	 MyList(const MyList & obj);
	 MyList& operator=(const MyList& obj);
	 const char operator[](int)const;
	  char& operator[](int);
	  bool palindrome(char*ptr);
	  ~MyList();
	  int* getarr()const;
};

