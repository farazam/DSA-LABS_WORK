#include<iostream>
#include"List.h"
#include"MyList.h"
using namespace std;
int main()
{

	char* ptr = new char[100];
	cout << "Enter line: ";
	cin.getline(ptr, 50);
	int size = 0;
	while (ptr[size] != '\0')
	{
		size++;
	}
	MyList obj(size);
	for (int i = 0; i < size; i++)
	{
			obj.addElement(ptr[i]);
	}
	bool flag=obj.palindrome(ptr);
	if (flag)
	{
		cout << "\nTHis Line is Plaidrome\n";
	}
	else
	{
		cout << "\nTHis Line is not Plaidrome\n";
	}
}
