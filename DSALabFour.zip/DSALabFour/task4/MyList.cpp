#include "MyList.h"
#include<iostream>
using namespace std;
void MyList::addElement(int s)
{
	if (!full())
	{
		arr[currentsize++] = s;
	}
	else
	{
		cout << "\nList is full\n";
	}
}
int MyList::removeElement()
{
	if (!empty())
	{
		return arr[--currentsize];
	}
	else
	{
		return -1;
	}
}
int* MyList::getarr()const
{
	int* localtemp = new int[maxsize];
	for (int i = 0; i < currentsize; i++)
	{
		localtemp[i] = arr[i];
	}
	return localtemp;
}
bool MyList::empty()
{
	if (currentsize == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool MyList::full()
{
	if (currentsize == maxsize)
	{
		return true;
	}
	else
	{
		return false;
	}
}
int MyList::size()
{
	return currentsize;
}
int MyList::last()
{
	if (!empty())
	{
		return arr[currentsize - 1];
	}
	else
	{
		return -1;
	}
}
MyList::MyList(int s ):List(s)
{
}
MyList::MyList(const MyList& obj):List(obj)
{
}
MyList& MyList::operator=(const MyList& obj)
{
	maxsize = obj.maxsize;
	currentsize = obj.currentsize;
	arr = new char[maxsize];
	for (int i = 0; i < currentsize; i++)
	{
		arr[i] = obj.arr[i];
	}
	return*this;
}
const char MyList::operator[](int s)const
{
	if (s >= 0 && s < maxsize)
	{
		return arr[s];
	}
	else
	{
		return arr[0];
	}
}
char& MyList::operator[](int s)
{
	if (s >= 0 && s < maxsize)
	{
		return arr[s];
	}
	else
	{
		return arr[0];
	}
}
MyList::~MyList()
{
	/*cout << "\nMylist destructor\n";*/
}


bool MyList::palindrome(char *ptr)
{
	int len = 0;
	bool flag = false;
	while (ptr[len] != '\0')
	{
		len++;
	}
	char* localtemp = new char[len+1];
	for (int i = 0; i < len; i++)
	{
		localtemp[i] = removeElement();
	}
	localtemp[len] = '\0';
	

	bool flag1 = false;
	for (int i = 0; i < len; i++)
	{
		if(localtemp[i]==arr[i])
		{
			flag = true;
			flag1 = true;

		}
		else
		{
			flag = false;
			break;
		}
	}
	if (flag1 == true)
	{
		return true;
	}
	else
	{
		return false;
	}
}