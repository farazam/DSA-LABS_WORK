#include<iostream>
#include"List.h"
#include"MyList.h"
using namespace std;

int presedence(char c)
{
	switch (c)
	{
	  case '+':
	  {
		  return 1;
	  }break;
	  case'-':
	  {
		  return 1;
	  }break;
	  case '*':
	  {
		  return 2;
	  }break;
	  case '/':
	  {
		  return 2;
	  }break;
		
	}
}
int main()
{
	
	int x=0, y=0;
	char infix[100]; char postfix[100];
	char reverse[100]; char prefix[100];
	cout << "\nENter expressionn :";
	cin >> infix;
	int len = 0;
	while (infix[x] != '\0')
	{
		x++;

	}
	MyList obj(x);
	x++;
	char c;
	infix[x + 1] = '\0';
	infix[x--] = ')';
	while (x > 0)
	{
		infix[x] = infix[x-1];
		x--;
	}
	infix[x] = '(';
	/*cout << "\nAfte adding brackets :" << infix << endl;*/

	int size = 0;

	while (infix[size] != '\0')
	{
		size++;
	}
	/*cout << size << endl;*/
	int j = 0;
	for (int i = size; i >= 0; i--)
	{
		reverse[j] = infix[i-1];
		j++;
	}
	j--;
	reverse[j] = '\0';
	/*cout << "\nReversed Expression :"<<reverse;*/
	for (int k = 0; k < j; k++)
	{
		if (reverse[k] == ')')
		{
			reverse[k] = '(';
		}
		else if (reverse[k] == '(')
		{
			reverse[k] = ')';
		}
	}
	/*cout << "\nReversed Expression :" << reverse;*/


	for (int k = 0; k < j; k++)
	{
		infix[k] = reverse[k];
	}
	/*cout << "\nInfix reverse :" << infix;*/



	while (infix[x] != '\0')
	{
		if (infix[x] == '(')
		{
			obj.addElement(infix[x]);
		}
		else if (infix[x] >= 'a' && infix[x] <= 'z' ||infix[x]>='0' &&infix[x]<='9'|| infix[x] >= 'A' && infix[x] <= 'Z')
		{
			postfix[y] = infix[x];
			y++;
		}
		else if (infix[x] == '+' || infix[x] == '-' || infix[x] == '*' || infix[x] == '/')
		{
			while (obj.last()=='+'|| obj.last() == '-'|| obj.last() == '*'|| obj.last() == '/')
			{
				if (presedence(obj.last()) >= presedence(infix[x]))
				{
					postfix[y] = obj.removeElement();
					y++;
				}
				else
				{
					break;
				}
				
			}
			obj.addElement(infix[x]);
			
		}
		else if (infix[x] == ')')
		{
			c = obj.removeElement();
			
			while(c!= '(')
			{
				
				
				postfix[y] =c;
				c = obj.removeElement();
				

				y++;
			}
		}
		x++;
	}
	postfix[y] = '\0';
	


	int len1 = 0;
	while (postfix[len1] != '\0')
	{
		len1++;
	}
	int rev = 0;
	for (int k = len1; k >= 0; k--)
	{
		prefix[rev] = postfix[k-1];
		rev++;
	}

	prefix[rev-1] = '\0';
	cout << "\nPrefix Expression :" << prefix << endl;
}