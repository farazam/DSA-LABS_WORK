#include"Stack.h"
#include<iostream>
using namespace std;
template <class T>
class myStack :public Stack<T>
{
public:
	myStack():Stack<T>()
	{
		/*Stack<T>::arr = new T[size];
		Stack<T>::max_size = size;
		Stack<T>::current_size = 0;*/
	}
	myStack(const myStack&obj):Stack<T>(obj)
	{
	}
	~myStack()
	{

	}
	 void  addElement(T data)
	
{
		if (isfull())
		{
			cout << "Stack is full : \n";
		}
		else
		{
			Stack<T>::regrow(data);
			Stack<T>::maxsize++;
			/*Stack<T>::arr[Stack<T>::current_size++] = data;*/
		}
	}


	T removeElement()
	{
		if (!isempty())
		{
			Stack<T>::currentsize--;
			return Stack<T>::arr[Stack<T>::currentsize];
		}
		else
		{
			return -1;
		}

	}

	T top()
	{
		if (!isempty())
		{
			return Stack<T>::arr[Stack<T>::currentsize - 1];
		}
		else
		{
			return -1;
		}
	}
	bool isfull()
	{
		if (Stack<T>::currentsize == Stack<T>::maxsize)
		{
			return true;
		}
		else
			return false;
	}
	bool isempty()
	{
		if (Stack<T>::currentsize == 0)
		{
			return true;
		}
		else
			return false;
	}
	T* getarr()const
	{
		T* localtemp = new T[Stack<T>::maxsize];
		for (int i = 0; i < Stack<T>::currentsize; i++)
		{
			localtemp[i] = Stack<T>::arr[i];
		}
		return localtemp;
	}

	int size()
	{
		return Stack<T>::currentsize;
	}
	
};

