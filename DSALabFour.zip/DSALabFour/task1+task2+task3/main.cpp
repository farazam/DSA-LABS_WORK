#include<iostream>
#include"Stack.h"
#include"myStack.h"
using namespace std;
template <class T>
void ShowStack(myStack <T>& obj);


int main()
{
	myStack<int>obj;
	ShowStack(obj);
	cout << "\nAdding Elements In STack :\n";
	obj.addElement(5);
		obj.addElement(8);
		obj.addElement(9);
		ShowStack(obj);
		cout << "\nElement on top oF Stack is :" << obj.top()<<endl;
		obj.removeElement();
		obj.removeElement();
		ShowStack(obj);
		obj.removeElement();
		obj.removeElement();
		ShowStack(obj);
}

template <class T>
void ShowStack(myStack <T>& obj)
{
	T* localtemp = obj.getarr();
	if (!obj.isempty())
	{
		cout << "Total number of elements in stack are : " << obj.size() << '\n';
		cout << "\nStack :\n";
		for (int i = 0; i < obj.size(); i++)
		{

			cout << localtemp[i] << endl;
		}
	}
	else
	{
		cout << "\nStack is empty\n";
	}
}
