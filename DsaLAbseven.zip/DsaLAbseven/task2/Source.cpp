#include<iostream>
#include"Mylinklist.h"
using namespace std;

void menu()
{
	cout << "\nEnter Choice You want To Do:\n";
	cout << "\n1-> Stack\n";
	cout << "\n2-> Queue\n";
	cout << "\n3->Display all elements of Stack\n";
	cout << "\n4->Display All elements of Queue\n";
	cout << "\n0-> To Terminate\n";
}
int main()
{


	MylinkList* obj = new MylinkList();
	MylinkList* obj1 = new MylinkList();
	int choice;
	menu();
	cin >> choice;
	while(choice!=0)
	{
		switch (choice)
		{
		case 1:
		{
			cout << "\n Enter choice :\n";
			int c;
			cout << "1-> Push\n";
			cout << "2->Pop\n";
			cout << "3-> Get Peek Element\n";
			cin >> c;
			switch (c)
			{
			case 1:
			{
				cout << "\nEnter Element :";
				int data;
				cin >> data;
				obj->insertattail(data);
				menu();
				cin >> choice;
			}break;
			case 2:
			{
				obj->removefromtail();
				menu();
				cin >> choice;
			}break;
			case 3:
			{
				cout << "\nTop Most Element of Stack is\n";
				cout << obj->getback();
				menu();
				cin >> choice;
			}break;
			default:
			{
				cout << "\nYou opted wrong option\n";
				menu();
				cin >> choice;
			}
			}

		}break;
		case 2:
		{
			cout << "\n Enter choice :\n";
			int c;
			cout << "1-> Add Element\n";
			cout << "2-> Remove Element\n";
			cout << "3-> Get Front Value\n";
			cout << "4-> Get Rear Value\n";
			cin >> c;
			switch (c)
			{
			case 1:
			{
				cout << "\nEnter Element :";
				int data;
				cin >> data;
				obj1->insertattail(data);
				menu();
				cin >> choice;
			}break;
			case 2:
			{
				obj1->removefromhead();
				menu();
				cin >> choice;
			}break;
			case 3:
			{
				cout << "\nFront Value of Queue is:" << obj1->getfront();
				menu();
				cin >> choice;
			}break;
			case 4:
			{
				cout << "\nRear Value of Queue is:" << obj1->getback();
				menu();
				cin >> choice;
			}break;
			default:
			{
				cout << "\nYou opted wrong option\n";
				menu();
				cin >> choice;
			}
			}
		}break;
		case 3:
		{
			system("cls");
			cout << "\nStack is :\n";
			obj->display();
			menu();
			cin >> choice;
		}break;
		case 4:
		{
			system("cls");
			cout << "\nQueue is :\n";
			obj1->display();
			menu();
			cin >> choice;
		}break;
		default:
		{
			cout << "\nYou opted wrong option\n";
			menu();
			cin >> choice;
		}
		}


	}
}