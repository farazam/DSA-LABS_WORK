#pragma once
#include"LinkList.h"
#include<iostream>
using namespace std;
class MylinkList : public LinkList {
public:
	MylinkList()
	{
		head = nullptr;
		tail = nullptr;
		/*currentsize = 0;*/
	}


	void insertattail(int data)
	{
		node* temp = new node();
		temp->data = data;
		temp->next = nullptr;
		if (head == nullptr)
		{
			head = temp;
			tail = temp;
		}
		else
		{
			tail->next = temp;
			tail = temp;
		}
		/*currentsize++;*/
	}
	void insertathead(int data)
	{
		node* temp = new node();
		temp->data = data;
		temp->next = nullptr;
		if (head == nullptr)
		{
			head = temp;
			tail = temp;
		}
		else
		{
			temp->next = head;
			head = temp;
		}
		/*
		/currentsize++*/;
	}
	void removefromtail()
	{
		if (empty())
		{
			cout << "\nLInk List is empty\n";
		}
		else
		{
			node* temp = head;
			node* temp1 = head->next;
			if (temp1 != nullptr)
			{
				/*cout << "\nhelo\n";*/
				while (temp1->next != nullptr)
				{
					temp = temp->next;
					temp1 = temp1->next;
				}
				temp->next = nullptr;
				tail = temp;
				/*currentsize--;*/
			}
			else if (head == tail)
			{
				delete head;
				head = nullptr;
				tail = nullptr;
			}
			else
			{
				//delete[]temp1;
				temp1 = nullptr;
				/*currentsize--;*/

			}
		}
	}
	void removefromhead()
	{
		if (!empty())
		{
			node* temp = head;
			head = head->next;
			temp->next = nullptr;
			/*currentsize--;*/
		}
		else
		{
			cout << "\nLink lIst is empty\n";
		}
	}

	int getfront()
	{
		int front;
		node* temp = head;
		front = temp->data;
		return front;
	}
	int getback()
	{
		int back;
		node* temp = head;
		while (temp->next != nullptr)
		{
			temp = temp->next;

		}
		back = temp->data;
		return back;
	}
	bool empty()
	{
		if (head == nullptr)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	void display()
	{
		if (!empty())
		{
			node* temp = head;

			cout << "\nLink list is :\n";
			//cout << temp->data << endl;
			while (temp != nullptr)
			{
				cout << temp->data << endl;
				temp = temp->next;
				//cout << temp->data << endl;

			}
		}
		else
		{

			cout << "\nLink List is empty Nothing To Display\n";

		}
	}
	int getsize()
	{
		int currentsize = 0;
		node* temp = head;
		while (temp != nullptr)
		{
			currentsize++;
			temp = temp->next;
		}
		return currentsize;
	}
};