#include<iostream>
#include"Mylinklist.h"
using namespace std;

int main()
{
	MylinkList* obj=new MylinkList();
	obj->insertathead(10);
	obj->insertathead(11);
	obj->insertattail(12);
	obj->insertathead(13);
	obj->display();
	cout << "\nCurrent Size of Link List :\n" << obj->getsize() << endl;
	cout << "\nBack Value of LinkList :";
	cout << obj->getback() << endl; 
	obj->removefromtail();
	obj->removefromtail();
	obj->display();
	cout << "\nFront ELement of Link List :";
	cout << obj->getfront() << endl;
	obj->removefromtail();
	obj->display();
	obj->removefromtail();
	obj->display();
}