#pragma once
struct node {
	int data;
	node* next;
};

class LinkList {
protected:
	node* head;
	node* tail;
	/*int currentsize;
	int front;
	int back;*/
public:
	virtual void insertattail(int) = 0;
	virtual void removefromhead() = 0;
	virtual void removefromtail() = 0;
	virtual void insertathead(int) = 0;
	virtual int getsize() = 0;
	virtual int getfront() = 0;
	virtual int getback() = 0;
	virtual bool empty() = 0;
	virtual void display() = 0;

};
