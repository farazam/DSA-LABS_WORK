#include<iostream>
#include"Mylinklist.h"
using namespace std;
void menu()
{
	cout << "\nENter choice you want to do :\n";
	cout << "\n1-> TO search Element\n";
	cout << "\n2-> TO Remove Duplicates\n";
	cout << "\n0-> to Termiante\n";
}
int main()
{

	MylinkList* obj=new MylinkList();
	obj->insertathead(10);
	obj->insertathead(11);
	obj->insertathead(12);
	obj->insertathead(12);
	obj->insertathead(11);
	obj->insertathead(10);
	obj->insertathead(15);
	obj->insertathead(16);
	obj->insertathead(17);
	obj->insertattail(12);

	obj->display();
	int choice;
	menu();
	cin >> choice;
	while(choice!=0)
	{ 
		switch (choice)
		{
		case 1:
		{
			cout << "\nENter ELement to search :\n";
			int c;
			cin >> c;
			obj->search(c);
			menu();
			cin >> choice;
		}break;
		case 2:
		{
			obj->remove_Duplicates();
			cout << "\nDuplicates Removed Succesfully\n";
			menu();
			cin >> choice;
		}break;
		case 0:
		{
			choice = 0;
		}
		default:
		{
			cout << "\nYou oPted Wrong Option\n";
			menu();
			cin >> choice;
		}
		}
	}
}