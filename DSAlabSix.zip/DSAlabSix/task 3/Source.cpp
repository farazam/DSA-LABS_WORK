#include"myCircularQueue.h"
#include<iostream>
using namespace std;
template <class T>
void showCircularQueue(myCircularQueue <T>& obj);
template <class T>
void Reverse(myCircularQueue <T>& obj);

template <class T>
bool palindrome(myCircularQueue <T>& obj, myCircularQueue <T>& obj1, int size);



int main()
{


	/*myCircularQueue <int> obj1(5);*/
	string read;

	cout << "\nENter input :";
	cin >> read;
	int size = read.size();
	myCircularQueue <char> obj1(size);
	myCircularQueue <char> obj(size);
	for (int i = 0; i < size; i++)
	{
		obj.enqueue(read[i]);
		obj1.enqueue(read[i]);
	}
	showCircularQueue(obj);

	bool flag = palindrome(obj, obj1,size);
	if (flag)
	{
		cout << "\nThis Queue is Palindrome\n";
	}
	else
	{
		cout << "\nThis Queue is not Palindrome\n";
	}
	
}

template <class T>
void showCircularQueue(myCircularQueue <T>& obj)
{
	if (!obj.isempty())
	{
		cout << "\nQueue is :\n";
		T* ptr = obj.getarr();
		for (int i = 0; i < obj.getsize(); i++)
		{
			cout << ptr[i] << endl;
		}
	}
	else
	{
		cout << "\nQueue is Empty\n";
	}
}
template <class T>
void Reverse(myCircularQueue <T>& obj)
{
	char data = 'c';
	if (!obj.isempty())
	{
		data = obj.Front_();
		obj.dequeue();
		Reverse(obj);
		obj.enqueue(data);
	}
}
template <class T>
bool palindrome(myCircularQueue <T>& obj, myCircularQueue <T>& obj1, int size)
{
	Reverse(obj);
	bool flag = false;
	T* ptr = obj.getarr();
	T* ptr1 = obj1.getarr();
	for (int i = 0; i < size; i++)
	{
		if (ptr[i] == ptr1[i])
		{
			flag = true;
		}
		else
		{
			flag = false;
			break;
		}
	}
	return flag;

}