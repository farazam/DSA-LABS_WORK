#include"myCircularQueue.h"
#include<iostream>
using namespace std;


template <class T>
void showCircularQueue(myCircularQueue <T>& obj);
//template <class T>
//void Reverse(myCircularQueue <T>& obj)
//{
//	
//	char data='c';
//	if(!obj.isempty())
//	{  
//		data = obj.Front_();
//		obj.dequeue();
//		Reverse(obj);
//		obj.enqueue(data);
//	}
//
//
//	
//}

int main()
{


	/*myCircularQueue <int> obj1(5);*/
	string read;

	cout << "\nENter input :";
	cin >> read;
	int size = read.size();
	myCircularQueue <char> obj1(size);
	myCircularQueue <char> obj(size);
	for (int i = 0; i < size; i++)
	{
		obj.enqueue(read[i]);
		obj1.enqueue(read[i]);
	}
	showCircularQueue(obj);

	/*Reverse(obj);
	showCircularQueue(obj);*/
	/*obj1.enqueue(5);
	obj1.enqueue(4);
	obj1.enqueue(3);
	obj1.enqueue(2);
	obj1.enqueue(1);
	showCircularQueue(obj1);
	obj1.dequeue();
	showCircularQueue(obj1);
	obj1.enqueue(1);
	showCircularQueue(obj1);*/
	
}
template <class T>
void showCircularQueue(myCircularQueue <T>& obj)
{
	if (!obj.isempty())
	{
		cout << "\nQueue is :\n";
		T* ptr = obj.getarr();
		for (int i = 0; i < obj.getsize(); i++)
		{
			cout << ptr[i]<<endl;
		}
	}
	else
	{
		cout << "\nQueue is Empty\n";
	}
}