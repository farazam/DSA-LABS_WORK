
#include"Queue.h"
#include<iostream>
using namespace std;
template <class T>
class myCircularQueue: public Queue<T>
{
	int rear = 0;
	int front = 0;
public:
	myCircularQueue(int size)
	{
		Queue<T>::arr = new T[size];
		Queue<T>::max_size = size;
		Queue<T>::no_of_elements = 0;
		Queue<T>::garbage = 0;
	}
	void enqueue(T data)
	{
		if (!isfull())
		{
			Queue<T>::rear = Queue<T>::rear % Queue<T>::max_size;
			Queue<T>::arr[Queue<T>::rear++] = data;
			Queue<T>::no_of_elements++;
		}
		else
		{
		
			cout << "\nQueue is full\n";
		}
	}
	T dequeue()
	{
		if (!isempty())
		{
			Queue<T>::front = Queue<T>::front % Queue<T>::max_size;
			Queue<T>::no_of_elements--;
			T temp = Queue<T>::arr[Queue<T>::front];
				Queue<T>::front++;
			return temp;
		}
		else
		{
			
			return Queue<T>::garbage;
		}
	}
	bool isempty()
	{
		if (Queue<T>::no_of_elements!=0)
		{
			return false;
		}
		else if(Queue<T>::no_of_elements == 0)
		{
			return true;
		}
		
	}
	bool isfull()
	{
		if (Queue<T>::no_of_elements != Queue<T>::max_size)
		{
			return false;
		}
		else if(Queue<T>::no_of_elements == Queue<T>::max_size)
		{
			return true;
		}
	}
	T Front_()
	{
		T f = Queue<T>::arr[Queue<T>::front];
		return f;
	}
	T getsize()
	{
		return Queue<T>::no_of_elements;
	}
	T* getarr()
	{
		T* localtemp = new T[Queue<T>::no_of_elements];
		for (int i = 0; i < Queue<T>::no_of_elements; i++)
		{
			localtemp[i] = Queue<T>::arr[i];
		}
		return localtemp;
	}
};