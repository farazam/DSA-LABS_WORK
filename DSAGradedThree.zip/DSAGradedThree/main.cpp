#include<iostream>
#include<string>
#include"myStack.h"
#include"Queue.h"
using namespace std;

int main()
{
	int  temp = 0;
	string read;
	cout << "\nEnter input :";
	cin >> read;
	int size = read.size();
	myStack <char>obj(size);
	Queue<int>obj1;
	for (int i = 0; i < size; i++)
	{
		if (read[i] >= '0' && read[i] <= '9')
		{
			obj.addElement(read[i]);
		}
		else
		{
			temp = (obj.removeElement() - 48);
			temp=temp*(obj.removeElement() - 48);
			obj1.enqueue(temp);
			
		}
	}
	obj1.display();
}

