#pragma once
#include<iostream>
using namespace std;
template <class T>
class Queue
{
	T* arr;
	int maxsize;
	int rear;
	int front;
public:
	Queue()
	{
		maxsize = 100;
		arr = new T[maxsize];
		front = 0;
		rear = 0;
		
	}
	Queue(const Queue& obj)
	{
		for (int i = 0; i < rear; i++)
		{
			arr[i] = obj.arr[i];
		}
	}
	~Queue()
	{
		delete[]arr;
		arr = nullptr;
	}
	void enqueue(T data)
	{
		if (!full())
		{
			arr[rear++] = data;
		}
		else
		{
			cout << "\nQueue Is Full\n";
		}
	}
	T Dequeue()
	{
		if (!empty())
		{
			 T t= arr[front];
			/*rerarrange();*/
			rear--;
			return t;
		}
		else
		{
			return -1;
		}
	}
	bool empty()
	{
		if (rear == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	bool full()
	{
		if (rear == maxsize)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	int size()
	{
		return rear;
	}
	T _front()
	{
		T f=arr[front];
		return f;
	}
	void display()
	{
		for (int i = 0; i < rear; i++)
		{
			cout << arr[i];
		}
	}
};