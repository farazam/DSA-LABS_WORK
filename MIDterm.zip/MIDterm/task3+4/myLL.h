#pragma once
#include"LinkList.h"
#include<iostream>
using namespace std;

template <class T>
class myLL:public LinkList<T>
{
public:
	myLL():LinkList<T>()
	{

	}
	void insertAtEnd(T data)
	{
		node<T>* temp = new node<T>();
		temp->data = data;
		temp->next = nullptr;
		if (LinkList<T>::head == nullptr)
		{
			LinkList<T>::head = temp;
		}
		else
		{
			node<T>* temp1 = LinkList<T>::head;
			while (temp1->next != nullptr)
			{
				temp1 = temp1->next;
			}
			temp1->next = temp;
		}
	}
	

	T deleteFromHead()
	{
		if (!isEmpty())
		{
			node<T>* temp = LinkList<T>::head;
			T extra = temp->data;
			LinkList<T>::head = LinkList<T>::head->next;
			temp->next = nullptr;
			return extra;
		}
		else
		{
			cout << "\nReturning Garbage\n";
			LinkList<T>::head = nullptr;
			return 0;
		}
	}
	
	void display()
	{
		if (!isEmpty())
		{
			node<T>* temp = LinkList<T>::head;

			cout << temp->data;
			while (temp->next != nullptr)
			{
				temp = temp->next;
				cout << temp->data;

			}
		}
		else
		{
			cout << "\nLink List is Empty\n";
		}
	}
	bool isEmpty()
	{
		if (LinkList<T>::head!=nullptr)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	
};
