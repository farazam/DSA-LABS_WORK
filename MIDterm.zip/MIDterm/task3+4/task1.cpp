#include<iostream>
#include"LinkList.h"
#include"myQueue.h"
#include"myLL.h"
using namespace std;
template<class T> 
myQueue <T> reverseQueue(myQueue <T>& obj1);
int main()
{
  

	cout << "\n\n---------- Best of Luck for the Exam ---------\n\n";
	myQueue<char> q1;
	q1.enqueue('D');
	q1.enqueue('S');
	q1.enqueue('A');
	q1.enqueue(' ');
	q1.enqueue('L');
	q1.enqueue('A');
	q1.enqueue('B');
	q1.display();
	myQueue<char> reverseQ1 = reverseQueue(q1);
	cout << endl;
	reverseQ1.display();
	return 0;
}


template<class T>
myQueue <T> reverseQueue(myQueue <T>& obj1)



{







	if (!obj1.isEmpty())
	{
		T extra;
		extra = obj1.dequeue();
		reverseQueue(obj1);
		obj1.enqueue(extra);

	}
	return obj1;






}