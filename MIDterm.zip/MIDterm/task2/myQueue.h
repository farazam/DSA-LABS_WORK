#pragma once
#include<iostream>
#include"Queue.h"
#include"LinkList.h"
#include"myLL.h"
using namespace std;
template <class T>
class myQueue :public Queue<T>
{
public:
	void enqueue(T data)
	{
		Queue<T>::obj.insertAtEnd(data);
	}


	T dequeue()
	{
		T extra =Queue<T>::obj.deleteFromHead();
		return extra;
	}
	void display()
	{
		Queue<T>::obj.display();
	}


	bool isEmpty()
	{
		if (Queue<T>::obj.isEmpty())
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	
};
