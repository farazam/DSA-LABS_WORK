#include<iostream>
#include"LinkList.h"
#include"myQueue.h"
#include"myLL.h"
using namespace std;

int main()
{
   myQueue<int>* obj=new myQueue<int>();
   obj->enqueue(1);
   obj->enqueue(2);
   obj->enqueue(3);
   obj->enqueue(4);
   obj->enqueue(5);
   cout << "\nQueue:\n";
   obj->display();

   cout << "\nAfter Dequeue :\n";
   int extra =obj->dequeue();
   obj->display();
   cout << "\nDeleted Value :"<<extra<<endl;
   obj->dequeue();
   obj->dequeue();
   obj->dequeue();
   obj->dequeue();
   cout << "\nDeleted All Elements oF Queue :\n";
   obj->display();
}