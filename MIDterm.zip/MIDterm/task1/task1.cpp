#include<iostream>
#include"LinkList.h"
#include"myLL.h"
using namespace std;

int main()
{
   myLL<int>* obj=new myLL<int>();

   obj->insertAtEnd(1);
   obj->insertAtEnd(2);
   obj->insertAtEnd(3);
   obj->insertAtEnd(4);
   obj->insertAtEnd(5);
   obj->insertAtEnd(6);
   cout << "\nLink List :\n";
   obj->display();

   cout << "\nAfter Removal of Head :\n";
   int extra =obj->deleteFromHead();
   obj->display();
   cout << "\nDeleted Value :"<<extra<<endl;
}