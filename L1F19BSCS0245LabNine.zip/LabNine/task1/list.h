#include<iostream>
using namespace std;
struct node
{
	int data;
	node* next;
};

class LinkList
{
protected:
	node* head;
public:
	LinkList()
	{
		head = nullptr;
		/*tail = nullptr;*/
	}


	void addtail(int data)
	{
		node* temp = new node();
		temp->data = data;
		temp->next = nullptr;
		if (head == nullptr)
		{
			head = temp;
			/*tail = temp;*/
		}
		else
		{
			node* temp1 = head;
			while (temp1->next != nullptr)
			{
				temp1 = temp1->next;
			}
			temp1->next = temp;
			/*tail->next = temp;*/
			/*tail = temp;*/
		}
	}
	void RemovefromTail()
	{
		node* temp = head;
		node* temp1 = head;
		int c = 0;
		while (temp->next != nullptr)
		{
			c++;
			temp = temp->next;
		}
		//temp->next = nullptr;
		if (c > 0)
		{
			while (temp1->next != temp)
			{
				temp1 = temp1->next;
			}

			temp1->next = nullptr;
			delete temp;
			temp = nullptr;
		}
		else
		{
			head = nullptr;
		}

	}

	void addHead(int data)
	{
		node* temp = new node();
		temp->data = data;
		temp->next = nullptr;
		if (head == nullptr)
		{
			head = temp;
		}
		else
		{
			temp->next = head;
			head = temp;
		}
	}
	
	void removehead()
	{
		if (!isempty())
		{
			node* temp = head;
			head = head->next;
			temp->next = nullptr;
		}
		else
		{
			head = nullptr;
		}
	}
	int size()
	{
		int count = 0;
		node* temp = head;
		while (temp != nullptr)
		{
			temp = temp->next;
			count++;
		}
		return count;
	}
	int gethead()
	{
		if (!isempty())
		{
			return head->data;
		}
		else
		{
			cout << "\\nLink lIst is Empty\n";
			cout << "\nReturning garbage\n";
			return 0;
		}
	}
	int gettail()
	{
		if (!isempty())
		{
			node* temp = head;
			while (temp->next != nullptr)
			{
				temp = temp->next;
			}
			return temp->data;
		}
		else
		{
			cout << "\\nLink lIst is Empty\n";
			cout << "\nReturning garbage\n";
			return 0;
		}
	}


	void insertSorted(int data)
	{
		addHead(data);
		int extra = 0;
		node* temp = head;
		node* temp1 = head->next;
		while (temp != nullptr)
		{
			while (temp1 != nullptr)
			{
				if (temp->data < temp1->data)
				{
					extra = temp->data;
					temp->data = temp1->data;
					temp1->data = extra;
				}
				temp1 = temp1->next;
			}
			temp1 = temp;
			temp = temp->next;
		}
	}
	void display()
	{
		if (!isempty())
		{
			node* temp = head;

			cout << temp->data << endl;
			while (temp->next != nullptr)
			{
				temp = temp->next;
				cout << temp->data << endl;

			}
		}
		else
		{
			cout << "\nLink List is Empty\n";
		}
	}
	bool isempty()
	{
		int c = size();
		if (c > 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	void insertAtPosition(int pos,int data)
	{
		int s = size();
		if (pos != 0 && pos-1 <= s)
		{

			if (pos == 1)
			{
				addHead(data);
			}
			else if (pos-1 == s)
			{
				addtail(data);
			}
			else
			{
				node* temp = head;
				for (int i = 1; i < pos-1;i++)
				{
					temp = temp->next;
				}
				node* temp1 = temp->next;
				node* temp2 = new node();
				temp2->data = data;
				temp2->next = temp1;
				temp->next = temp2;
				
			}
		}
	}
	void removeFromPosition(int pos)
	{
		int s = size();
		if (pos != 0 && pos  <= s)
		{

			if (pos == 1)
			{
				removehead();
			}
			else if (pos == s)
			{
				RemovefromTail();
			}
			else
			{
				node* temp = head;
				for (int i = 1; i < pos-1; i++)
				{
					temp = temp->next;
				}
				node* temp1 = temp->next;
				node* temp2 = temp1->next;
				temp->next =temp2;
				temp1->next =nullptr;
			}
		}
		else
		{
			cout << "\nRead Access Voilation\n";
			cout << "\nYour Position is beyond LiNk LIst limit\n";
		}
	}
	void remove(int start, int last)
	{
		int s = size();
		if (start != 0 && last <= s &&start!=last &&start+1!=last &&last>start)
		{
			if (start == 1 && last == s)
			{
				head = nullptr;
			}
			else 
			{
				node* temp = head;
				int c = 0;
				for (int i = 1; i < start-1; i++)
				{
					c++;
					temp = temp->next;
				}
				node* temp1 = head;
				for (int i = 1; i < last; i++)
				{
					temp1 = temp1->next;
				}
				temp->next = temp1->next;
			}
		}
		else
		{
			cout << "\nError in removing\n";
		}
	}
	~LinkList()
	{
		head = nullptr;
	}


};