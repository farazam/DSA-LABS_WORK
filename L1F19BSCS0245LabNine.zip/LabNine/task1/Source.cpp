#include<iostream>
#include"list.h"
using namespace std;

int main()
{
	LinkList* obj=new LinkList();
	obj->addtail(2);
	
	obj->addtail(4);
	obj->addtail(5);
	cout << "\nLinked List(Add on Tail) :\n";
	obj->display();
	obj->RemovefromTail();
	cout << "\nLinked List(Remove from Tail):\n";
	obj->display();
	obj->addHead(1);
	obj->addHead(5);
	obj->addHead(7);
	cout << "\nLinked List(Add On Head):\n";
	obj->display();
	obj->removehead();
	obj->removehead();
	obj->removehead();
	cout << "\nLinked List(Remove On Head):\n";
	obj->display();
	cout << "\nSize of LinkList:";
	cout<<obj->size()<<endl;
	cout << "\nHead Value of List:";
	cout << obj->gethead()<<endl;
	cout << "\nTail Value of List:";
	cout << obj->gettail()<<endl;
	obj->insertSorted(7);
	cout << "\nLink List (Sorted Addition in Ascending Order):\n";
	obj->display();

	cout << "\nLink List Insert At Position:\n";
	obj->insertAtPosition(2, 3);
	obj->display();
	obj->addHead(8);
	obj->addHead(9);
	cout << "\nLInk List :\n";
	obj->display();
	int start = 2;
	int last = 5;
	cout << "\nAfter Removal(Start,end):\n";
	cout << "\nStart :"<<start<<"\nEnd :"<<last;
	obj->remove(start, last);
	cout << "\nLink LIst:\n";
	obj->display();
}