#include"MyDlist.h"
#include<iostream>
using namespace std;

int main()
{
	MyDlist* obj = new MyDlist();
	MyDlist* obj1 = new MyDlist();
	obj->add_node_tail(20);
	obj->add_node_tail(22);
	obj->add_node_tail(24);
	obj->add_node_tail(26);
	obj->add_node_tail(28);
	
	
	
	cout << "\nLInked List:\n";
	obj->display();


	cout << "\nSorted INsert :\n";
	obj->sortedInsert(27);
	obj->display();


	cout << "\nTotal Elements OF Link LIst :\n";
	int total=obj->count();
	cout << total << endl;
	cout << endl;
	cout << "\nValue At nth Postion :";
	cout << obj->GetNth(3)<<endl;


	
	cout << "\nAfter Inserting at Nth Position LinkLIst:\n";
	obj->insertNth(3, 4);
	obj->display();



	cout << "\nValue POPed Out :";
	cout << obj->Pop()<<endl;


	




	obj->reverse();
	cout << "\nReversed Linked List:\n";
	obj->display();

	cout << "\nINsert Sort :\n";
	obj->insersort(10);
	obj->display();



	obj1->add_node_tail(99);
	obj1->add_node_tail(98);
	obj1->add_node_tail(98);
	obj1->add_node_tail(97);
	obj1->add_node_tail(96);
	obj1->add_node_tail(96);
	obj->addnodeHead(4);
	cout << "\nNew Link List :";
	obj1->display();
	
	cout << "\nAppended List :\n";
	obj->append(obj, obj1);
	cout << "\nAfter Append Link LIst 2:";
	obj1->display();
	cout<<"\nTotal Elements of Appended Link List :"<<obj->count()<<endl;
	cout << "\nAfter Removal of Duplicates :\n";
	obj->RemoveDuplicates();
	obj->display();
	cout << "\nElements LEft After removal of Duplicates :" << obj->count()<<endl;



	obj1->add_node_tail(1);
	obj1->add_node_tail(2);
	obj1->add_node_tail(3);


	

	cout << "\nLink List 2 :\n";
	obj1->display();
	cout << "\nShuffle Merge :\n";
	obj->shuffleMerge(obj, obj1);


	cout << "\nAfter Deleting Both Link LIst :";
	
	cout << "\n\nLink List 1 :";
	obj->DeleteList();
	obj->display();
	cout << "\nLink List 2:";
	obj1->DeleteList();
	obj1->display();

	
}