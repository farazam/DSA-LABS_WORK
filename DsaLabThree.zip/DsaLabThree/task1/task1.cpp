#include<iostream>
using namespace std;
void selection_sort(int arr[5])
{
	int temp;
	for (int i = 0; i < 5; i++)
	{
		for (int j = i + 1; j < 5; j++)
		{
			if (arr[i] > arr[j])
			{
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
	}
}
void display(int arr[5])
{
	cout << "After sorting (Ascending Order):\n";
	for (int i = 0; i < 5; i++)
	{
		cout << arr[i] << endl;
	}
}
int main()
{

	
	
	int temp;
	int arr[5];
	for (int i = 0; i < 5; i++)
	{
		cout << "\nEnter element :" << i + 1 << '\n';
		cin >> arr[i]; cout << endl;
	}
	selection_sort(arr);
	display(arr);
	
}