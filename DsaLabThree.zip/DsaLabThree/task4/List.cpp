#include"List.h"
List::List(int size)
{
	arr = new int[size];
	maxsize = size;
	currentsize = 0;
}
List::List(const List& obj)
{
	maxsize = obj.maxsize;
	currentsize = obj.currentsize;
	arr = new int[maxsize];
	for (int i = 0; i < currentsize; i++)
	{
		arr[i] = obj.arr[i];
	}
}
List:: ~List()
{
	delete[]arr;
	arr = nullptr;
}