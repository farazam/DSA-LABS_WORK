#include<iostream>
#include"List.h"
#include"MyList.h"
using namespace std;
void display(MyList& obj);

int main()
{

	MyList obj(5);
	obj.addElement(5);
	obj.addElement(6);
	obj.addElement(7);
	obj.addElement(8);
	obj.addElement(9);
	
	display(obj);

	cout << "Last elemet in List is :" << obj.last()<<endl;
	cout << "After Removing \n";
	obj.removeElement();
	obj.removeElement();
	obj.removeElement();
	obj.removeElement();
	display(obj);
	cout << "\nCurrent element present in list :"<<obj.size()<<endl;
	obj.removeElement();
	display(obj);
	obj.removeElement();
	display(obj);
}
void display(MyList& obj)
{
	int* localtemp = obj.getarr();
	if (!obj.empty())
	{
		cout << "\nMYLISt :\n";
		for (int i = 0; i < obj.size(); i++)
		{

			cout << localtemp[i] << endl;
		}
	}
	else
	{
		cout << "\nStack is empty\n";
	}
}