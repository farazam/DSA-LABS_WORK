#pragma once
class Cake
{
	char* type;
	int size;
	int No_of_pieces;
	bool decoration;
public:
	Cake();
	Cake(char* t, int s, int no, bool flag);
	Cake(const Cake& obj);
	~Cake();
	void settype(char* t);
	char* gettype()const;
	void setsize(int);
	int getsize()const;
	void setNoOfpieces(int);
	int getNoOfpieces()const;
	void setdecoration(bool);
	bool getdeocration()const;
	void display()const;
	double computeCost();
};

