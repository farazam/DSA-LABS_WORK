#include<iostream>
#include"Cake.h"
using namespace std;
int main()
{
	char* t = new char[9]{ 'C','h','o','c','l','a','t','e','\0' };
	Cake obj(t, 3, 10, true);
	cout << '\n';
	obj.display();
	if (obj.computeCost() == 0.0)
	{
		cout << "\nNo Price Available\n";
	}
	else
	{
		cout << "\nPrice of Cake is :" << obj.computeCost() << "$\n";
	}
}