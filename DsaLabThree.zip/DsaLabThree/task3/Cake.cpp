#include "Cake.h"
#include<iostream>
using namespace std;

Cake::Cake()
{
	type = nullptr;
	size = 0;
	No_of_pieces = 0;
	decoration = false;
}
Cake::Cake(char* t, int s, int no, bool flag)
{
	int length = 0;
	while (t[length] != '\0')
	{
		length++;
	}
	type = new char[length + 1];
	for (int i = 0; i < length; i++)
	{
		type[i] = t[i];
	}
	type[length] = '\0';
	size = s;
	No_of_pieces = no;
	decoration = flag;
}
Cake::Cake(const Cake& obj)
{
	int length = 0;
	while (obj.type[length] != '\0')
	{
		length++;
	}
	type = new char[length + 1];
	for (int i = 0; i < length; i++)
	{
		type[i] = obj.type[i];
	}
	type[length] = '\0';
	size = obj.size;
	No_of_pieces = obj.No_of_pieces;
	decoration = obj.decoration;
}
Cake::~Cake()
{
	delete[]type;
	type = nullptr;
	No_of_pieces = 0;
	size = 0;
	decoration = false;
}
void Cake::settype(char* t)
{
	int length = 0;
	while (t[length] != '\0')
	{
		length++;
	}
	type = new char[length + 1];
	for (int i = 0; i < length; i++)
	{
		type[i] = t[i];
	}
	type[length] = '\0';
}
char* Cake::gettype()const
{
	char* localtemp;
	int length = 0;
	while (type[length] != '\0')
	{
		length++;
	}
	localtemp= new char[length + 1];
	for (int i = 0; i < length; i++)
	{
		localtemp[i] = type[i];
	}
	localtemp[length] = '\0';
	return localtemp;
}
void Cake::setsize(int s)
{
	size = s;
}
int Cake::getsize()const
{
	return size;
}
void Cake::setNoOfpieces(int no)
{
	No_of_pieces = no;
}
int Cake::getNoOfpieces()const
{
	return No_of_pieces;
}
void Cake::setdecoration(bool flag)
{
	decoration = flag;
}
bool Cake::getdeocration()const
{
	return decoration;
}
void Cake::display()const
{
	if (size <= 3)
	{
		if (size <= 3 && decoration == true)
		{
			cout << "This Cake is " << size << " tier," << type << " cake with flower decoration and has " << No_of_pieces << " pieces of choclate\n";
		}
		else if (size <= 3 && decoration == false)
		{
			cout << "This Cake is " << size << " tier," << type << " cake with no flower decoration and has " << No_of_pieces << " pieces of choclate\n";
		}
	}
	else
	{
      cout << "\nno type found\n";
	}
	
}
double Cake::computeCost()
{
	double total=0.0;
	if (size > 3)
	{
		cout << "\nThere are only 3 tiers of cake available\n";
	}
	else
	{
		if (size == 1 && decoration == true)
		{
			total = 15 + 7 + (0.5 * No_of_pieces);
		}
		else
		{
			total = 15 + (0.5 * No_of_pieces);
		}
		if (size == 2 && decoration == true)
		{
			total = 25 + 13 + (1.0 * No_of_pieces);
		}
		else
		{
			total = 25 + (1.5 * No_of_pieces);
		}
		if (size == 3 && decoration == true)
		{
			total = 35 + 19 + (1.5 * No_of_pieces);
		}
		else
		{
			total = 35 + (1.5 * No_of_pieces);
		}
	}
	
	return total;
}