#pragma once
class Student
{
private:
	char* name;
	double CGPA;
public:
	Student();
	Student(char* n , double cgpa );
	~Student();
	Student(const Student& obj);
	void setname(char* n);
	char* getname()const;
	void setcgpa(double c);
	double getcgpa()const;
	
};

