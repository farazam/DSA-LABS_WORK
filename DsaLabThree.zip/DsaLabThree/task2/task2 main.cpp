#include<iostream>
#include"Student.h"
using namespace std;
void selection_sort(Student obj[10]);
int binary(Student obj[10], double c);
int linear(Student obj[10], double c);
void selection_sort(Student obj[10])
{
	Student temp;
	for (int i = 0; i < 10; i++)
	{
		for (int j = i + 1; j < 10; j++)
		{
			if (obj[i].getcgpa() > obj[j].getcgpa())
			{
				temp = obj[i];
				obj[i]=obj[j];
				obj[j]=temp;
			}
		}
	}
}
int binary(Student obj[10],double c)
{
	int first = 0;
	int last = 10 - 1;
	int mid;
	bool flag = false;
	int ind = 0;
	while (first <= last)
	{
		mid = (first+last)/2;
		if (obj[mid].getcgpa()==c)
		{
			flag = true;
			ind = mid;
			break;
		}
		else if (obj[mid].getcgpa() < c)
		{
			first = mid + 1;
		}
		else
		{
			last = mid - 1;
		}
	}
	if (flag == true)
	{
		return ind;
	}
	else
	{
		return -1;
	}
}
int linear(Student obj[10],double c)
{
	int ind = 0;
	bool flag = false;
	for (int i = 0; i < 10; i++)
	{
		if (obj[i].getcgpa() == c)
		{
			flag = true;
			ind = i;
			break;
		}
	}
	if (flag == true)
	{
		return ind;
	}
	else
	{
		return -1;
	}

}
int main()
{
	char* n= new char[100];
	Student obj[10];
	double value;
	cout << "ENter Details :\n";
	for (int i = 0; i < 10; i++)
	{
		cout << "\nENter reg no :";
		cin >> n;
		cout << "ENter CGPA oF student " << i + 1 << '\n';
		cin >> value;

		
		obj[i].setname(n);
		obj[i].setcgpa(value);
	}

	cout << "ENter cgpa to Search :";
	double c;
	cin >> c;
	int get=linear(obj,c);
	if (get == -1)
	{
		cout << "\nNOt found\n";

	}
	else
	{
		cout << "\nBY Linear search\n";
		cout << "\nCGPA Found at index " << get<<endl;
	}
	
	selection_sort(obj);

	int g=binary(obj, c);
	if (g == -1)
	{
		cout << "\nnot found\n";
	}
	else
	{
		cout << "By Binary Search\n";
		cout << "CGPA value found at index " << g;
	}
}