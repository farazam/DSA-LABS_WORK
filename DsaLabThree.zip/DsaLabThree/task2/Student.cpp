#include "Student.h"
Student::Student()
{
	name = nullptr;
	CGPA = 0.0;
}
Student::Student(char* n, double cgpa)
{
	int lentgh = 0;
	while (n[lentgh] != '\0')
	{
		lentgh++;
	}
	name = new char[lentgh + 1];
	for (int i = 0; i < lentgh; i++)
	{
		name[i] = n[i];

	}
	name[lentgh] = '\0';
	CGPA = cgpa;
}
Student::~Student()
{
	delete[]name;
	name = nullptr;
	CGPA = 0.0;
}
Student::Student(const Student& obj)
{
	int lentgh = 0;
	while (obj.name[lentgh] != '\0')
	{
		lentgh++;
	}
	name = new char[lentgh + 1];
	for (int i = 0; i < lentgh; i++)
	{
		name[i] = obj.name[i];

	}
	name[lentgh] = '\0';
	CGPA = obj.CGPA;
}
void Student::setname(char* n)
{
	int lentgh = 0;
	while (n[lentgh] != '\0')
	{
		lentgh++;
	}
	name = new char[lentgh + 1];
	for (int i = 0; i < lentgh; i++)
	{
		name[i] = n[i];

	}
	name[lentgh] = '\0';
}
char* Student::getname()const
{
	char* localtemp;
	int lentgh = 0;
	while (name[lentgh] != '\0')
	{
		lentgh++;
	}
	localtemp = new char[lentgh + 1];
	for (int i = 0; i < lentgh; i++)
	{
		localtemp[i] = name[i];

	}
	localtemp[lentgh] = '\0';
	return localtemp;
}
void Student::setcgpa(double c)
{
	CGPA = c;

}
double Student::getcgpa()const
{
	return CGPA;
}