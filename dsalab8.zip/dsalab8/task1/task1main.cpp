#include"D_Linklist.h"
#include<iostream>
using namespace std;
void menu();

int main()
{
	D_Linklist* kaka = new D_Linklist();
	
	int opt = 110;

	while (opt != 0)
	{
		menu();
		cin >> opt;
		if(opt==1)
		{
	
			int temp;
			cout << "\nEnter value to add in Linklist on head:\n";
			cin >> temp;
			kaka->add_node_Head(temp);
			cout << "\nYour value Added\n";
			
		}
		else if (opt == 2)
		{
			int temp;
			cout << "\nEnter value to add in Linklist on tail:\n";
			cin >> temp;
			kaka->add_node_tail(temp);
			cout << "\nYour value Added\n";
			
		}
		else if (opt == 3)
		{
			int temp;
			cout << "\nEnter value to add in Linklist:\n";
			cin >> temp;
			int temp1 = 0;
			cout << "\nEnter value of node after which you want to add your new value :\n";
			cin >> temp1;
			kaka->add_node_aftervalue(temp, temp1);

			
		}
		else if (opt == 4)
		{
			int temp;
			cout << "\nEnter value to Delete:\n";
			cin >> temp;
			kaka->remove_node(temp);
			cout << "\nYour value Deleted\n";
		
		}
		else if (opt == 5)
		{
			cout << "\nTotal Members OF Link LIst :\n";
			cout<<kaka->count();
		
		}
		else if (opt == 6)
		{
			kaka->sortascending();
		
		}
		else if (opt == 7)
		{
			kaka->sortDescending();
		
		}
		else if (opt == 8)
		{
			cout << "\nLinked List :\n";
			kaka->display();
			
		}
		else if (opt == 9)
		{
			opt = 0;
			cout << "\nYour Program has Been Terminated\n";
		}
		else
		{
			cout << "\nWrong option\n";
		}
	}
}

void menu()
{
	cout << "\nEnter opt\n";
	cout << "\npress 1-> Insert at head";
	cout << "\npress 2-> Insert at tail";
	cout << "\npress 3->Insert at  specific position";
	cout << "\npress 4->Delete a specific node";
	cout << "\npress 5->total elements";
	cout << "\npress 6->Sort in Ascending order";
	cout << "\npress 7->Sort in Descending order";
	cout << "\npress 8->Display";
	cout << "\npress 9-> to Exit The Program\n";
}