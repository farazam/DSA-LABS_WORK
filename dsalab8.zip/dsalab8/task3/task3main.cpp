#include"D_Linklist.h"
#include<iostream>
using namespace std;

int main()
{
	D_Linklist* kaka = new D_Linklist();
	
	int opt = 110;

	kaka->add_node_Head(11);
	kaka->add_node_Head(17);
	kaka->add_node_Head(120);
	
	kaka->display();
	int temp = 0;
	cout << "total sum of nodes ";
	cout << kaka->gettotal();
	cout << endl;
	cout << "\nreverse \n";
	kaka->reverse();
	kaka->display();
	cout << "\nswap head tail \n";
	kaka->swap_head_Tail();
	kaka->display();
}

