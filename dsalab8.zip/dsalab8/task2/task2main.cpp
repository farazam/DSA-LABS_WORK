#include"D_Linklist.h"
#include<iostream>
using namespace std;

int main()
{
	D_Linklist* kaka = new D_Linklist();
	
	int opt = 110;

	kaka->add_node_Head(11);
	kaka->add_node_Head(12);
	kaka->add_node_Head(13);
	kaka->add_node_Head(14);
	kaka->add_node_Head(15);
	kaka->add_node_Head(16);
	kaka->add_node_Head(17);
	kaka->add_node_Head(18);
	kaka->add_node_Head(19);
	kaka->add_node_Head(20);
	kaka->add_node_Head(21);
	kaka->display();
	int temp = 0;
	temp=kaka->search(15);
	if (temp == 0)
	{
		cout << "your value not found\n";
	}
	else
	{
		cout << "your value found at " << temp << endl;;
	}
}

