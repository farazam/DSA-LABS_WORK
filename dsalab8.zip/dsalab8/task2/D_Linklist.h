#pragma once
#include<iostream>
using namespace std;
struct node
{
	int data;
	node* next;
	node* prev;
};

class D_Linklist
{
protected:
	node* head;
	node* tail;
public:
    D_Linklist()
	{
		head = nullptr;
		tail = nullptr;
	}
	int search(int data)
	{
		node* temp = head;
		bool check = false;
		int index = 0;
		int size = count();
		for (int i = 0; i < size; i++)
		{
			if (temp->data == data)
			{
				check = true;
				index++;
				break;
			}
			index++;
			temp = temp->next;
		}

		if (check == false)
		{
			index = 0;
		}

		return index;
	}
	int count()
	{

		int total = 0;
		node* temp = head;
		while (temp->next != head)
		{
			total++;
			temp = temp->next;
		}
		total++;

		return total;
	}


	void remove_node(int value)
	{
		node* temp = head;
		while (temp->next != head)
		{
			if (temp->data == value)
			{
				break;
			}
			temp = temp->next;
		}
		 if (temp == head)
		{
		head = head->next;
		head->prev = nullptr;
		tail->next = head;

		}
		else if (temp == tail)
		{
			tail = tail->prev;
			tail->next->prev = nullptr;
			tail->next = head;
			
		}
		
		else
		{
			temp->prev->next = temp->next;
			temp->next->prev = temp->prev;
			temp->next = nullptr;
			temp->prev = nullptr;
		}
	}
	void add_node_aftervalue(int data, int value)
	{
		node* temp = head;
		bool flag = false;
		while (temp->next != head)
		{
			if (temp->data == value)
			{
				flag = true;
				if (temp == tail)
				{
					add_node_tail(data);
				}
				else
				{
					node* temp1 = new node();
					temp1->data = data;
					temp1->next = nullptr;
					temp1->prev = nullptr;
					temp1->next = temp->next;
					temp->next = temp1;
					temp1->prev = temp;
					temp1->next->prev = temp1;
				}
				break;
			}
			temp = temp->next;
		}
		if (temp->data == value)
		{
			flag = true;
			if (temp == tail)
			{
				add_node_tail(data);
			}
			else
			{
				node* temp1 = new node();
				temp1->data = data;
				temp1->next = nullptr;
				temp1->prev = nullptr;
				temp1->next = temp->next;
				temp->next = temp1;
				temp1->prev = temp;
				temp1->next->prev = temp1;
			}
		}

		if (flag == false)
		{
			cout << "\nValue is not present\n";
		}
		else
		{
			cout << "\nYour value Added\n";
		}

	}
	void add_node_tail(int data)
	{
		node* temp = new node();
		temp->next = nullptr;
		temp->prev = nullptr;
		temp->data = data;
		if (head == nullptr)
		{
			head = temp;
			tail = temp;
			head->prev = tail;
			tail->next = head;
		}
		else
		{
			tail->next = temp;
			temp->prev = tail;
			tail = temp;
			tail->next = head;
		}
	}


	void add_node_Head(int data)
	{
		node* temp = new node();
		temp->next = nullptr;
		temp->prev = nullptr;
		temp->data = data;
		if (head == nullptr)
		{
			head = temp;
			tail = temp;
			head->prev = tail;
			tail->next = head;
		}
		else
		{
			head->prev = temp;
			temp->prev = tail;
			temp->next = head;
			head = temp;
			tail->next = temp;
		}
	}

	void sortascending()
	{
		node* temp = head;
		node* temp1;
		int temp2 = 0;
		int size = count();
		for (int i = 0; i < size; i++)
		{
			temp1 = temp->next;
			for (int j = i + 1; j < size; j++)
			{
				if (temp->data > temp1->data)
				{
					

					swap(temp->data, temp1->data);
				}

				temp1 = temp1->next;
			}
			temp = temp->next;
		}

	}
	void sortDescending()
	{
		node* temp = head;
		node* temp1;
		int temp2 = 0;
		int size = count();
		for(int i=0;i<size;i++)
		{
			temp1 = temp->next;
			for (int j = i+1; j < size; j++)
			{
				if (temp->data < temp1->data)
				{
				
					swap(temp->data, temp1->data);
				}

				temp1 = temp1->next;
			}
			temp = temp->next;
		}
	}

	void display()
	{
		node* temp = head;
		cout << temp->data << '\n';
		while (temp->next != head)
		{
			temp = temp->next;
			cout << temp->data << '\n';
		}
	}

	~D_Linklist()
	{
		node* temp = head;
		while (temp->next != head)
		{
			head = head->next;
			head->prev = nullptr;
			tail->next = head;
		}
		temp = nullptr;
		head->next = nullptr;
	}

};