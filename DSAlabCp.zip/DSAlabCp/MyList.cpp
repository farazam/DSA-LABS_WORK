#include "MyList.h"
#include<iostream>
using namespace std;
void MyList::addElement(int s)
{
	if (!full())
	{
		arr[currentsize] = s;
		/*cout<<endl << arr[currentsize]<<endl;*/
		currentsize++;
	}
	else
	{
		cout << "\nList is full\n";
	}
}
int MyList::removeElement()
{
	if (!empty())
	{
		/*cout << endl << arr[currentsize-1] << endl;*/
		return arr[--currentsize];
	}
	else
	{
		return -1;
	}
}
int* MyList::getarr()const
{
	int* localtemp = new int[maxsize];
	for (int i = 0; i < currentsize; i++)
	{
		localtemp[i] = arr[i];
	}
	return localtemp;
}
bool MyList::empty()
{
	if (currentsize == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool MyList::full()
{
	if (currentsize == maxsize)
	{
		return true;
	}
	else
	{
		return false;
	}
}
int MyList::size()
{
	return currentsize;
}
int MyList::last()
{
	if (!empty())
	{
		return arr[currentsize - 1];
	}
	else
	{
		return -1;
	}
}
MyList::MyList(int s ):List(s)
{
}
MyList::MyList(const MyList& obj):List(obj)
{
}
MyList& MyList::operator=(const MyList& obj)
{
	maxsize = obj.maxsize;
	currentsize = obj.currentsize;
	arr = new int[maxsize];
	for (int i = 0; i < currentsize; i++)
	{
		arr[i] = obj.arr[i];
	}
	return*this;
}
const int MyList::operator[](int s)const
{
	if (s >= 0 && s < maxsize)
	{
		return arr[s];
	}
	else
	{
		return arr[0];
	}
}
int& MyList::operator[](int s)
{
	if (s >= 0 && s < maxsize)
	{
		return arr[s];
	}
	else
	{
		return arr[0];
	}
}
MyList::~MyList()
{
	/*cout << "\nMylist destructor\n";*/
}