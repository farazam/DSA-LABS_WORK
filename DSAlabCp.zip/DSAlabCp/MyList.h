#pragma once
#include"List.h"
class MyList: public List
{
public:
	void addElement(int) ;
	 int removeElement();
	 bool empty();
	 bool full();
	 int size();
	 int last();
	 MyList(int s = 0);
	 MyList(const MyList & obj);
	 MyList& operator=(const MyList& obj);
	 const int operator[](int)const;
	  int& operator[](int);
	  ~MyList();
	  int* getarr()const;
};

