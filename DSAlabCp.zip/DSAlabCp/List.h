#pragma once
class List
{
protected:
	int* arr;
	int maxsize;
	int currentsize;
public:
	virtual void addElement(int) = 0;
	virtual int removeElement() = 0;
	List(int size=0);
	List(const List& obj);
	virtual ~List();
};

