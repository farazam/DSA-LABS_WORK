#pragma once
class myArray
{
	int* arr;
	int maxsize;
	int currentsize;
public:
	myArray(int s=0);
	myArray(const myArray& obj);
	~myArray();
	bool insert(int);
	bool delete_right();
	bool delete_left();
	void display();
	bool search(int value, int &index);
};

