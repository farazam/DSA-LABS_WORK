#include<iostream>
#include"myArray.h"
using namespace std;
int menu()
{
	int choice;
	cout << "\nPress 1 for Insertion";
	cout << "\nPress 2 for Deletion from right";
	cout << "\nPress 3 for Deletion from left";
	cout << "\nPress 4 to display data";
	cout << "\nPress 5 to search an element";
	cout << "\nPress 0 to Terminate\n";
	cin >> choice;
	return choice ;
}
int main()
{
	int choice = menu();
	myArray obj(5);
	
	while (choice != 0)
	{
		switch (choice)
		{
		case 1:
		{
			cout << "\nEnter element to add in Array:\n";
			int s;
			cin >> s;
			bool flag=obj.insert(s);
			if (flag == true)
			{
				cout << "\nInsert Succesfully\n";
				choice = menu();
			}
			else
			{
				cout << "\nArray full\n";
				choice = menu();
			}

		}break;
		case 2:
		{
			bool flag;
			flag = obj.delete_right();
				if (flag == true)
				{
					cout << "\nDeleted from right succesfully\n";
					choice = menu();
				}
				else
				{
					cout << "\nArray empty\n";
					choice = menu();
				}
		}break;
		case 3:
		{
			bool flag=obj.delete_left();
			if (flag == true)
			{
				cout << "\nDeleted from left succesfully\n";
				choice = menu();
			}
			else
			{
				cout << "\nArray is empty\n";
				choice = menu();
			}
		}break;
		case 4:
		{
			obj.display();
			choice = menu();
		}break;
		case 5:
		{
			int element;
			cout << "\nENter elemen tot search :";
			cin >> element;
			int index;
			bool flag;
			flag=obj.search(element, index);
			if (flag == true)
			{
				cout << "\nElement found at index :" << index << endl;
				choice = menu();
			}
			else
			{
				cout << "\nELement not found \n";
				choice = menu();
			}
		}break;
		case 0:
		{
			choice = 0;
		}
		default:
		{
			cout << "\nYou Opted Wrong Option\n";
			choice = menu();
		}
		}
	}
}