#include "myArray.h"
#include<iostream>
using namespace std;

myArray::myArray(int s )
{
	maxsize = s;
	arr = new int[maxsize];
	currentsize = 0;
}
myArray::myArray(const myArray& obj)
{
	maxsize = obj.maxsize;
	currentsize = obj.currentsize;
	arr = new int[maxsize];
	for (int i = 0; i < currentsize; i++)
	{
		arr[i] = obj.arr[i];
	}
}
myArray::~myArray()
{
	delete[]arr;
	arr = nullptr;
}
bool myArray::insert(int s)
{
	bool flag = false;
	if (currentsize != maxsize)
	{
		arr[currentsize++] = s;
		flag=true;
	}
	else
	{
		flag=false;
	}
	return flag;
}
bool myArray::delete_right()
{
	bool flag = false;
	if (currentsize != 0)
	{
		--currentsize;
		flag = true;
	}
	else
	{
		flag =false;
	}
	return flag;
}
bool myArray::delete_left()
{
	bool flag = false;
	if (currentsize != 0)
	{

		flag = true;
		int* newarr = new int[currentsize];
		for (int i = 0; i < currentsize; i++)
		{
			newarr[i] = arr[i];
		}
		arr = new int[currentsize - 1];
		for (int i = 0; i < currentsize - 1; i++)
		{
			arr[i] = newarr[i + 1];
		}
		currentsize--;
	}
	else
	{
		flag = false;
	}
	return flag;
}
void myArray::display()
{
	if (currentsize != 0)
	{
		cout << "\nArray :\n";
		for (int i = 0; i < currentsize; i++)
		{
			cout << i << ". " << arr[i] << endl;
		}
	}
	else
	{
		cout << "\nArray is empty\n";
	}
}
bool myArray::search(int value, int& index)
{
	
	bool flag = false,flag1=false;
	for (int i = 0; i < currentsize; i++)
	{
		if (arr[i] == value)
		{
			flag = true;
			flag1 = true;
			index = i;
			break;
		}
		else
		{
			flag = false;
		}

	}

	if (flag1 == true)
	{
		return true;
	}
	else
	{
		index = -1;
		return false;
	}
}