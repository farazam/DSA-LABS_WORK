#pragma once
#include<iostream>
using namespace std;
struct node
{
	int data;
	node* left;
	node* right;;
};
class BST
{
protected:
	node* root;
public:
	BST()
	{
		root= nullptr;
	}

	void insert(int data)
	{
		node* newnode = new node();
		newnode->left = nullptr;
		newnode->right = nullptr;
		newnode->data = data;
		if (root == nullptr)
		{
			root = newnode;
		}
		else
		{
			node* temp1 = root;
			node* temp2 = root;
			while (temp1 != nullptr)
			{
				temp2 = temp1;
				if (data < temp1->data)
				{
					temp1 = temp1->left;
				}
				else
				{
					temp1 = temp1->right;
				}
			}
			if (data < temp2->data)
			{
				temp2->left = newnode;
			}
			else
			{
				temp2->right = newnode;
			}
			
		}
	}
	int count()
	{
		node* current = root;
		int c = leaf(current);
		return c;
	}
	void inorder()
	{
		node* temp = root;
		in_order(temp);
	}
	void preorder()
	{
		node* temp = root;
		pre_order(temp);
	}
	void postorder()
	{
		node* temp = root;
		post_order(temp);
	}

	
private:
	int leaf(node*current)
	{
		if (current == nullptr)
		{
			return 0;
		}
		else
		{
			if (current->left != nullptr || current->right != nullptr)
			{
				return leaf(current->left) + leaf(current->right);
			}
			else
			{
				return 1;
			}
		}
	}
	void in_order(node* temp)
	{
		if (temp == nullptr)
		{
			/*cout << "\nhello\n";*/
			return;
		}
		else
		{
			
			//temp = temp->left;
			/*cout << "\nleft\n";*/
			in_order(temp->left);
			/*cout << "\nparent\n";*/
			cout << temp->data << " \n";
			//temp = temp->right;
			/*cout << "\nright\n";*/
			in_order(temp->right);
			
		}
	}

	void pre_order(node* temp)
	{
		if (temp == nullptr)
		{
			return;
		}
		else
		{
			//temp = temp->left;
			/*cout << "\nleft\n";*/
			cout << temp->data << '\n';
			/*cout << "\nparent\n";*/
			pre_order(temp->left);
			pre_order(temp->right);
			//temp = temp->right;
				/*cout << "\nright\n";*/
		}
	}
	void post_order(node* temp)
	{
		if (temp == nullptr)
		{
			return;
		}
		else
		{
			 //temp = temp->left;
		  /*cout << "\nleft\n";*/
			post_order(temp->left);
			post_order(temp->right);
			//temp = temp->right;
				/*cout << "\nright\n";*/
			cout << temp->data << '\n';
			/*cout << "\nparent\n";*/

		}
	}

};