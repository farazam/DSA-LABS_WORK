#pragma once
#include<iostream>
using namespace std;
struct node
{
	int data;
	node* left;
	node* right;
};
class BST
{
protected:
	node* root;
public:
	BST()
	{
		root= nullptr;
	}

	void insert(int data)
	{
		node* newnode = new node();
		newnode->left = nullptr;
		newnode->right = nullptr;
		newnode->data = data;
		if (root == nullptr)
		{
			root = newnode;
		}
		else
		{
			node* temp1 = root;
			node* temp2 = root;
			while (temp1 != nullptr)
			{
				temp2 = temp1;
				if (data < temp1->data)
				{
					temp1 = temp1->left;
				}
				else
				{
					temp1 = temp1->right;
				}
			}
			if (data < temp2->data)
			{
				temp2->left = newnode;
			}
			else
			{
				temp2->right = newnode;
			}
			
		}
	}
	void inorder()
	{
		node* temp = root;
		in_order(temp);
	}
	void search(int data)
	{
		node* current = root;
		searching(current, data);
	}
private:
	void in_order(node* temp)
	{
		if (temp == nullptr)
		{
			/*cout << "\nhello\n";*/
			return;
		}
		else
		{
			
			//temp = temp->left;
			/*cout << "\nleft\n";*/
			in_order(temp->left);
			/*cout << "\nparent\n";*/
			cout << temp->data << " \n";
			//temp = temp->right;
			/*cout << "\nright\n";*/
			in_order(temp->right);
			
		}
	}
	void searching(node* current,int data)
	{
		bool flag = false;
		if (current != nullptr)
		{
			if (data == current->data && current != nullptr)
			{
				flag = true;
				cout << "\nElement Found "<<data<<"\n";
				return;
			}
			else if (data > current->data && current != nullptr)
			{
				current = current->right;
				searching(current, data);
			}
			else if (data < current->data && current != nullptr)
			{
				current = current->left;
				searching(current, data);
			}
		}
		else
		{
			cout << "\nNot found :"<<data<<"\n";
		}
	}

	

};