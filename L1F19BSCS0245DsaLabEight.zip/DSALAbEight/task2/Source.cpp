#include"MyDlist.h"
#include<iostream>
using namespace std;
void menu()
{
	cout << "\nEnter Choice\n";
	cout << "\n1-> Insert at tail";
	cout << "\n2-> Insert at Head";
	cout << "\n3->INsert At Position";
	cout << "\n4->Delete A NOde";
	cout << "\n5->Display";
	cout << "\n6-> Sort Ascending";
	cout << "\n7->Sort Descending";
	cout << "\n8->Count all elements\n";
	cout << "9->Search An Element\n";
	cout << "0-> to Exit The Program\n";
}
int main()
{
	MyDlist * obj = new MyDlist();
	int value;
	int choice = 0;
	menu();
	cin >> choice;
	while (choice != 0)
	{
		switch (choice)
		{
		case 1:
		{
			cout << "\nEnter Element TO ADD:\n";
			cin >> value;
			obj->add_node_tail(value);
			cout << "\nYour Element Has been Added\n";
			menu();
			cin >> choice;
		}break;
		case 2:
		{
			cout << "\nEnter Element TO ADD:\n";
			cin >> value;
			obj->addnodeHead(value);
			cout << "\nYour Element Has been Added\n";
			menu();
			cin >> choice;
		}break;
		case 3:
		{
			cout << "\nEnter Element TO ADD:\n";
			cin >> value;
			int value1 = 0;
			cout << "\nEnter Value Of Node after which you want to add your Value :\n";
			cin >> value1;
			obj->add_node_aftervalue(value, value1);

			menu();
			cin >> choice;
		}break;
		case 4:
		{
			cout << "\nEnter Element TO DELETE:\n";
			cin >> value;
			obj->remove_node(value);
			cout << "\nYour Element Has been Deleted\n";
			menu();
			cin >> choice;
		}break;
		case 5:
		{
			cout << "\nLinked List :\n";
			obj->display();
			menu();
			cin >> choice;
		}break;
		case 6:
		{
			obj->sortascending();
			cout << "\nYOUR LINK LIST HAS BEEN SORTED\n";
			menu();
			cin >> choice;
		}break;
		case 7:
		{
			obj->sortDescending();
			cout << "\nYOUR LINK LIST HAS BEEN SORTED\n";
			menu();
			cin >> choice;
		}break;
		case 8:
		{
			obj->count();
			menu();
			cin >> choice;
		}break;
		case 9:
		{
			cout << "\nEnter Element TO Search:\n";
			cin >> value;
			int c=obj->search(value);
			if (c==0)
			{
				cout << "\nElement Not Found\n";
			}
			else
			{
				cout << "\nElement Found at position : "<<c<<endl;
			}
			menu();
			cin >> choice;
		}break;
		case 0:
		{
			choice = 0;
			cout << "\nYour Program has Been Terminated\n";
		}break;

		default:
		{
			cout << "\nYou Choose Wrong option\nTerminating Program\n";
			cout << "               ------------           ";
		}
		}
	}

}