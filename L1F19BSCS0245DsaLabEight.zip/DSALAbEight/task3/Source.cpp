#include"MyDlist.h"
#include<iostream>
using namespace std;

int main()
{
	MyDlist* obj = new MyDlist();
	obj->add_node_tail(20);
	obj->add_node_tail(21);
	obj->add_node_tail(22);
	obj->add_node_tail(23);
	obj->add_node_tail(24);
	
	cout << "\nLInked List:\n";
	obj->display();

	obj->reverse();
	cout << "\nReversed Linked List:\n";
	obj->display();

	cout << "\nAfter Swapping Head Value with Tail Value:\n";
	obj->swapHeadTail();
	obj->display();
	cout << "\nTotal Sum of Linked List :" << obj->getTotal() << endl;

	cout << "\nLInked List:\n";
	obj->display();

}