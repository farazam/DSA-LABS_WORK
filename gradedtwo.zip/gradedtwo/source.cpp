#include<iostream>
#include<string>
#include"Stack.h"
#include"myStack.h"
using namespace std;
template <class T>
void ShowStack(myStack <T>& obj);
template <class T>
void reverse(myStack <T>& obj, myStack <T>& obj1,int size)
{
	for (int i = 0; i < size; i++)
	{
		obj.removeElement();
	}
	T t;
	for (int i = 0; i <size; i++)
	{
	
		obj.addElement(obj1.removeElement());
	}
}

int main()
{

	string read;

	cout << "\nENter input :";
	cin >> read;
	int size = read.size();

	myStack<char>obj(size);
	myStack<char>obj1(size);
	for (int i = 0; i < size; i++)
	{
		obj.addElement(read[i]);
		obj1.addElement(read[i]);
	}
	ShowStack(obj); 

	reverse(obj,obj1,size);
	ShowStack(obj);

	/*ShowStack(obj);
	cout << "\nAdding Elements In STack :\n";
	obj.addElement(5);
		obj.addElement(8);
		obj.addElement(9);
		ShowStack(obj);
		cout << "\nElement on top oF Stack is :" << obj.top()<<endl;
		obj.removeElement();
		obj.removeElement();
		ShowStack(obj);
		obj.removeElement();
		obj.removeElement();*/
		
}

template <class T>
void ShowStack(myStack <T>& obj)
{
	T* localtemp = obj.getarr();
	if (!obj.isempty())
	{
		cout << "Total number of elements in stack are : " << obj.size() << '\n';
		cout << "\nStack :\n";
		for (int i = 0; i < obj.size(); i++)
		{

			cout << localtemp[i] << endl;
		}
	}
	else
	{
		cout << "\nStack is empty\n";
	}
}
