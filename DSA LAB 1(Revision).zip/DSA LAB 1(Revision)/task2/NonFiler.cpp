#include "NonFiler.h"
NonFiler::~NonFiler()
{

}
NonFiler::NonFiler(string n, string a, string c, char* no, int g, float t,float adfee) :Loan(n, a, c, no, g, t)
{
	penaltyCharged = adfee;
}
double NonFiler::calculateTax()
{

	double b = taxRate / 100;
	double c;
	c = grossSalary * b;
	b = penaltyCharged / 100;
	b = b * grossSalary;
	b = b + c;
	return b;
}