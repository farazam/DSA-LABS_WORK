#include<iostream>
#include"ForFiler.h"
#include"NonFIler.h"
using namespace std;
int main()
{
	char* no = new char[13]{ '0','3','1','2','-','1','2','3','4','5','6','7','\0' };
	ForFiler o_obj("Faraz", "Block undefined", "Lahore", no, 63, 1.5);
	cout << "\nTax OF For Filer:" << o_obj.calculateTax();
	NonFiler t_obj("Faraz", "Block undefined", "Lahore", no, 63, 2.5, 0.5);
	cout << "\nTax Of Non Filer :" << t_obj.calculateTax();

}