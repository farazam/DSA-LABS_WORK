#include "Loan.h"


Loan::Loan(string n, string a, string c, char* no, int g, float t)
{
	name = n;
	address = a;
	city = c;

	grossSalary = g;


	taxRate = t;
	int len = 0;
	while (no[len] != '\0')
	{
		len++;
	}
	char* phoneNo = new char[len + 1];
	for (int i = 0; i < len; i++)
	{
		phoneNo[i] = no[i];
	}
	phoneNo[len] = '\0';
}

Loan::~Loan()
{
	delete[]phoneNo;
	phoneNo = nullptr;
}