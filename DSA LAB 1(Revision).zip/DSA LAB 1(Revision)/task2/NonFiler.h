#pragma once
#include"Loan.h"
class NonFiler:public Loan
{
	float penaltyCharged;
public:
	~NonFiler();
	NonFiler(string n = "", string a = "", string c = "", char* no = nullptr, int g = 0, float t = 2.5,float adfee=0.5);
	double calculateTax();
};

