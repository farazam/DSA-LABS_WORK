#pragma once
#include<ostream>
using namespace std;
#include<string>
class Loan
{
protected:
	string name;
	string address;
	string city;
	char* phoneNo;
	int grossSalary;
	float taxRate;
public:

	virtual double calculateTax() = 0;
 Loan(string n = "", string a = "", string c = "", char* no = nullptr, int g=0, float t = 1.5);
	virtual ~Loan();
};

