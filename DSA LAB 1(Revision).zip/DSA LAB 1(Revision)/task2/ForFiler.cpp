#include "ForFiler.h"
ForFiler::~ForFiler()
{

}
ForFiler::ForFiler(string n, string a, string c, char* no, int g, float t):Loan(n,a,c,no,g,t)
{

}
double ForFiler::calculateTax()
{

	double b =taxRate/100;
	double c;
	c = grossSalary * b;
	return c;
}