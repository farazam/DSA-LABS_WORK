#pragma once
#include "Loan.h"
class ForFiler:public Loan
{
public:
	~ForFiler();
	ForFiler(string n = "", string a = "", string c = "", char* no = nullptr, int g = 0, float t = 1.5);
	double calculateTax();
};

