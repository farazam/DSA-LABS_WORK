#include<iostream>
#include"Shape.h"
#include"Cylinder.h"
#include"Rectangle.h"
#include"PainNeeded.h"
#include"Sphere.h"
using namespace std;
int main()
{
	char* name = new char[9]{ 'C','y','l','i','n','d','e','r','\0' };
	char* name1 = new char[10]{ 'R','e','c','t','a','n','g','l','e','\0' };
	char* name2 = new char[7]{ 'S','p','h','e','r','e','\0' };
	Shape* s;
	Cylinder c_obj(name,10,30);
	s = &c_obj;
	Rectangle r_obj(name1, 20, 35);
	Sphere s_obj(name2, 15);
	PainNeeded obj(s,12);
	float total = obj.calculateAmount(s);
	cout << "\nTotal amount of paint needed in shape "<<s->toString()<<" :";
	cout << total;
	s = &r_obj;
	total = obj.calculateAmount(s);
	cout << "\nTotal amount of paint needed in shape " << s->toString() << " :";
	cout << total;

	s = &s_obj;
	total = obj.calculateAmount(s);
	cout << "\nTotal amount of paint needed in shape " << s->toString() << " :";
	cout << total;
	delete[]name;
	name = nullptr;
	delete[]name1;
	name = nullptr;
	delete[]name2;
	name = nullptr;

}