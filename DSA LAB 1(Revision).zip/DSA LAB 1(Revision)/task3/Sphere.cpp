#include "Sphere.h"
#include<iostream>
using namespace std;
Sphere::Sphere(char* s , float r):Shape(s)
{
	cout << "\nSphere constructor\n";
	radius = r;
}
Sphere::~Sphere()
{
	cout << "\nSphere Destructor\n";
	radius = 0.0;
}
float Sphere::area()
{
	float a = 4 * 3.14 * (radius * radius);
	return a;
}
char* Sphere::toString()const
{
	int len = 0;
	while (shapeName[len] != '\0')
	{
		len++;
	}
	char* localtemp = new char[len + 1];
	

	for (int i = 0; i < len; i++)
	{
		localtemp[i] = shapeName[i];
	}
	localtemp[len] = '\0';
	return localtemp;
}