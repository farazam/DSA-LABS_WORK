#pragma once
#include"Shape.h"
class Rectangle:public Shape
{
private:
	float length;
	float width;
public:
	Rectangle(char* s = nullptr, float len = 0.0, float wid = 0.0);
	~Rectangle();
	float area();
	char* toString()const;
};

