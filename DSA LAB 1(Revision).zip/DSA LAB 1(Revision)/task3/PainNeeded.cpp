#include "PainNeeded.h"
#include"Shape.h"
#include<iostream>
using namespace std;
float PainNeeded::calculateAmount(Shape*s)
{
	s_inst = s;
	float a=s_inst->area();
	a = a / coverage;
	return a;
}
PainNeeded::PainNeeded(Shape*s , float c)
{
	cout << "\nPAint Constructor\n";
	coverage = c;
	s_inst = s;
}
PainNeeded::~PainNeeded()
{
	/*delete[]s_inst;
	s_inst = nullptr;*/

	cout << "\nPaint Destructor \n";
}
