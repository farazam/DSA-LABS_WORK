#pragma once
#include"Shape.h"
class Cylinder :public Shape
{
private:
	float radius;
	float height;
public:
	Cylinder(char* s = nullptr, float r = 0.0, float h = 0.0);
	~Cylinder();
	float area();
	char* toString()const;
};

