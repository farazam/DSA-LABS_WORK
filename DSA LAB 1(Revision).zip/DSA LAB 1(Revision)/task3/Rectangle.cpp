#include "Rectangle.h"
#include<iostream>
using namespace std;
Rectangle::Rectangle(char* s , float len , float wid):Shape(s)
{
	cout << "\nRectangle constructor\n";
	length = len;
	width = wid;
}
Rectangle::~Rectangle()
{
	cout << "\nRectangle Destructor\n";
}
float Rectangle::area()
{
	float a = length * width;
	return a;
}
char* Rectangle::toString()const
{
	int len = 0;
	while (shapeName[len] != '\0')
	{
		len++;
	}
	char* localtemp = new char[len + 1];


	for (int i = 0; i < len; i++)
	{
		localtemp[i] = shapeName[i];
	}
	localtemp[len] = '\0';
	return localtemp;
}