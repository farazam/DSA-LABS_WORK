#pragma once
#include"Shape.h"
class PainNeeded
{
private:
	Shape* s_inst;
	float coverage;
public:
	float calculateAmount(Shape*s);
	PainNeeded(Shape* s = nullptr, float c=0.0);
	~PainNeeded();

};

