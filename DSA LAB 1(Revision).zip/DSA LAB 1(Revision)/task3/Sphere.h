#pragma once
#include "Shape.h"
class Sphere:public Shape
{
private:
	float radius;
public:
	Sphere(char* s = nullptr,float r=0.0);
	~Sphere();
	float area();
	char* toString()const;
};

