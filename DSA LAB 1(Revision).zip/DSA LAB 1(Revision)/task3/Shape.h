#pragma once
class Shape
{
protected:
	char* shapeName;
public:
	Shape(char* s = nullptr);
	virtual ~Shape();
	virtual float area() = 0;
	virtual char*toString()const = 0;
};

