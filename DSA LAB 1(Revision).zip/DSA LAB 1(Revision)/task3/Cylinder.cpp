#include "Cylinder.h"
#include<iostream>
using namespace std;
Cylinder::Cylinder(char* s, float r, float h ) :Shape(s)
{

	cout << "\nCylinder constructor\n";
	radius = r;
	height=h;
}
Cylinder::~Cylinder()
{
	cout << "\nCylinder Destructor\n";
}
float Cylinder::area()
{
	float a =3.14*(radius*radius)*height;
	return a;
}
char* Cylinder::toString()const
{
	int len = 0;
	while (shapeName[len] != '\0')
	{
		len++;
	}
	char* localtemp = new char[len + 1];


	for (int i = 0; i < len; i++)
	{
		localtemp[i] = shapeName[i];
	}
	localtemp[len] = '\0';
	return localtemp;
}