#include "Shape.h"
#include<iostream>
using namespace std;
Shape::Shape(char* s )
{
	cout << "\nShape Constrcutor\n";
	int len = 0;
	while (s[len] != '\0')
	{
		len++;
	}
	shapeName = new char[len + 1];

	for (int i = 0; i < len; i++)
	{
		shapeName[i] = s[i];
	}
	shapeName[len] = '\0';
}

Shape:: ~Shape()
{
	cout << "\nShape Destrcutor\n";
	delete[]shapeName;
		shapeName = nullptr;
}