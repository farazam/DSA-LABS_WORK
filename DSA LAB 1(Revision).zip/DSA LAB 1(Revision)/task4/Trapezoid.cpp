#include "Trapezoid.h"
#include<iostream>
using namespace std;
void Trapezoid::setheight(float h)
{
	height = h;
}
float Trapezoid::getheight()const
{
	return height;
}
Trapezoid::Trapezoid(float x, float y, float z , float w , float h):Quad(x,y,z,w)
{
	height = h;
}
Trapezoid::~Trapezoid()
{
	cout << "Trapezoid Destructor\n";
}
float Trapezoid::Area()
{
	float area = height * (getA() + getB());
		area = area / 2;
		return area;

}
float Trapezoid::Perimeter()
{
	float perimter = getA() + getB() + getC() + getD();
	return perimter;

}