#pragma once
#include"Quad.h"
class Rectangle:public Quad
{
public:
	Rectangle(float x = 0.0, float y = 0.0, float z = 0.0, float w = 0.0);
	float Area();
	float Perimeter();
	~Rectangle();
};

