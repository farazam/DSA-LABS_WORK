#pragma once
class Line
{
	float side;
public:
	Line(float s=0.0);
	~Line();
	float getside()const;
	void setside(float s);
};

