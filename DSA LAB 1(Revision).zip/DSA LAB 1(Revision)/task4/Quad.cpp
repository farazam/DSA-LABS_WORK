#include "Quad.h"
#include<iostream>
using namespace std;
void Quad::setA(float a)
{
	A.setside(a);
}
float Quad::getA()const
{
	return A.getside();
}
void Quad::setB(float a)
{
	B.setside(a);
}
float Quad::getB()const
{
	return B.getside();
}
void Quad::setC(float a)
{
	C.setside(a);
}
float Quad::getC()const
{
	return C.getside();
}
void Quad::setD(float a)
{
	D.setside(a);
}
float Quad::getD()const
{
	return D.getside();
}
Quad::Quad(float x , float y , float z, float w )
{
	A.setside(x);
	B.setside(y);
	C.setside(z);
	D.setside(w);
}
Quad::~Quad()
{
	cout << "\nQuad Destructor\n";
}