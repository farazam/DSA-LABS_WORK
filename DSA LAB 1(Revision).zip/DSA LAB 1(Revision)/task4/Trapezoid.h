#pragma once
#include"Quad.h"
class Trapezoid :public Quad
{
	float height;
public:
	void setheight(float h);
	float getheight()const;
	Trapezoid(float x = 0.0, float y = 0.0, float z = 0.0, float w = 0.0,float h=0.0);
	~Trapezoid();
	float Area();
	float Perimeter();
};

