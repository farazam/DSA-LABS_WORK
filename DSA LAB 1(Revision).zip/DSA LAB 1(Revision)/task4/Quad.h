#pragma once
#include"Line.h"
class Quad
{
	Line A;
	Line B;
	Line C;
	Line D;
public:
	Quad(float x=0.0, float y=0.0,float z = 0.0, float w = 0.0);
	void setA(float a);
	float getA()const;
	void setB(float a);
	float getB()const;
	void setC(float a);
	float getC()const;
	void setD(float a);
	float getD()const;
	virtual float Area() = 0;
	virtual float Perimeter() = 0;
	virtual ~Quad();
};

