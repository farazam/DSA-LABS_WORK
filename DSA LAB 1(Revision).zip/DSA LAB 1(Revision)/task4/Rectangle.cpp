#include "Rectangle.h"
#include<iostream>
using namespace std;
Rectangle::Rectangle(float x , float y , float z , float w):Quad(x,y,z,w)
{

}
float Rectangle::Area()
{
	float area = getA() * getB();
	return area;
}
float Rectangle::Perimeter()
{
	float perimeter = 2 * (getA() + getB());
	return perimeter;
}
Rectangle::~Rectangle()
{
	cout << "\nRectangle Destrcutor\n";
}