#include "Line.h"
Line::Line(float s)
{
	side = s;
}
Line::~Line()
{
	side = 0;
}
float Line::getside()const
{
	return side;
}
void Line::setside(float s)
{
	side = s;
}