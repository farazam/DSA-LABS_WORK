#include<iostream>
#include"OvernightPackage.h"
#include"TwoDayPackage.h"
using namespace std;
int main()
{
	char* no =new char[13] { '0','3','1','2','-','1','2','3','4','5','6','7','\0' };
	OvernightPackage o_obj("Faraz","Block undefined","Lahore",no,63.1,100,250);
	cout << "\nCost of Overnight Delivery :" << o_obj.calculateCost();
	TwoDayPackage t_obj("Faraz", "Block undefined", "Lahore", no, 63.1, 100, 250);
	cout << "\nCost of Twoday Pakage :" << t_obj.calculateCost();
	
}