#include "TwoDayPackage.h"
double TwoDayPackage::calculateCost()
{
	double ret;
	ret = weight * cost;
	ret = ret + fee;
	return ret;
}
TwoDayPackage::TwoDayPackage(string n, string a, string c, char* no, float w, float price, float f):Package(n,a,c,no,w,price)
{
	fee = f;
}
TwoDayPackage::~TwoDayPackage()
{
	fee = 0;
}