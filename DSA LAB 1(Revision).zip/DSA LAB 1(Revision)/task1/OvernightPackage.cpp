#include "OvernightPackage.h"
double OvernightPackage::calculateCost()
{
	double ret;
	ret = weight * cost;
	ret = ret + addfee;
	return ret;
}
OvernightPackage::OvernightPackage(string n, string a, string c, char* no, float w, float price, float f) :Package(n, a, c, no, w, price)
{
	addfee = f;
}
OvernightPackage::~OvernightPackage()
{
	addfee = 0;
}