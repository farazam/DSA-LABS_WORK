#pragma once
#include<iostream>
using namespace std;
class Package
{
protected:
	string name;
	string address;
	string city;
	char* phoneNo;
	float weight;
	float cost;
public:
	
	virtual double calculateCost() = 0;
	Package(string n="", string a="", string c="", char*no= nullptr, float w=0.0, float price =0.0);
	virtual ~Package();

};

