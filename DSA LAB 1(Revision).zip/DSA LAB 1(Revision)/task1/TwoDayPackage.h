#pragma once
#include"Package.h"
class TwoDayPackage :public Package
{
private:
	float fee;
public:
	double calculateCost();
	TwoDayPackage(string n = "", string a = "", string c = "", char* no = nullptr, float w = 0.0, float price = 0.0, float f = 0.0);
	~TwoDayPackage();

};

