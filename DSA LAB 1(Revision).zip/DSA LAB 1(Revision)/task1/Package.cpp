#include "Package.h"

Package::Package(string n, string a, string c, char* no, float w, float price)
{
	name = n;
	address = a;
	city = c;

		cost = price;
	

	weight = w;
	int len = 0;
	while (no[len] != '\0')
	{
		len++;
	}
	char* phoneNo = new char[len + 1];
	for(int i=0;i<len;i++)
	{
		phoneNo[i] = no[i];
	}
	phoneNo[len] = '\0';


}
Package::~Package()
{
	delete[]phoneNo;
	phoneNo = nullptr;
}