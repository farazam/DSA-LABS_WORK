#include<iostream>
#include"BST.h"
using namespace std;
int main()
{
	BST* obj = new BST();
	obj->insert(15);
	obj->insert(10);
	obj->insert(20);
	obj->insert(8);
	obj->insert(12);
	obj->insert(16);
	obj->insert(25);

	obj->inorder();
	
	obj->LSFind(3);


}