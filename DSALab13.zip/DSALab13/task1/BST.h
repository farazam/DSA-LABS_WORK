#pragma once
#include<iostream>
using namespace std;
struct node
{
	int data;
	node* left;
	node* right;
};
class BST
{
protected:
	node* root;
public:
	BST()
	{
		root= nullptr;
	}
	
	void insert(int data)
	{
		node* newnode = new node();
		newnode->left = nullptr;
		newnode->right = nullptr;
		newnode->data = data;
		if (root == nullptr)
		{
			root = newnode;
		}
		else
		{
			node* temp1 = root;
			node* temp2 = root;
			while (temp1 != nullptr)
			{
				temp2 = temp1;
				if (data < temp1->data)
				{
					temp1 = temp1->left;
				}
				else
				{
					temp1 = temp1->right;
				}
			}
			if (data < temp2->data)
			{
				temp2->left = newnode;
			}
			else
			{
				temp2->right = newnode;
			}
			
		}
	}
	void LSFind(int itr)
	{
		int smallest;
		int largest;
		node* current = root;
		node* current1 = root;
		
		itr--;
		
			while (current != nullptr &&current1!=nullptr &&itr>1)
			{
				if (itr == 0)
				{
					break;
				}
				else
				{
					current = current->left;
					current1 = current1->right;
				}
				itr--;
			}
			smallest = current->left->data;
			largest = current1->right->data;
		cout << "\nsmallest element:" << smallest;
		cout << "\nLargest element:" << largest<<endl;
	}
	void inorder()
	{
		node* temp = root;
		if (temp != nullptr)
		{
			in_order(temp);
		}
		else
		{
			cout << "\nNothing Left to Print\n";
		}
	}
private:
	void in_order(node* temp)
	{
		if (temp == nullptr)
		{
			/*cout << "\nhello\n";*/
			return;
		}
		else
		{
			
			//temp = temp->left;
			/*cout << "\nleft\n";*/
			in_order(temp->left);
			/*cout << "\nparent\n";*/
			cout << temp->data << " \n";
			//temp = temp->right;
			/*cout << "\nright\n";*/
			in_order(temp->right);
			
		}
	}
};