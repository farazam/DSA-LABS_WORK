#pragma once
#include<iostream>
using namespace std;
struct node
{
	int data;
	node* left;
	node* right;
};
class BST
{
protected:
	node* root;
public:
	BST()
	{
		root= nullptr;
	}
	
	void insert(int data)
	{
		node* newnode = new node();
		newnode->left = nullptr;
		newnode->right = nullptr;
		newnode->data = data;
		if (root == nullptr)
		{
			root = newnode;
		}
		else
		{
			node* temp1 = root;
			node* temp2 = root;
			while (temp1 != nullptr)
			{
				temp2 = temp1;
				if (data < temp1->data)
				{
					temp1 = temp1->left;
				}
				else
				{
					temp1 = temp1->right;
				}
			}
			if (data < temp2->data)
			{
				temp2->left = newnode;
			}
			else
			{
				temp2->right = newnode;
			}
			
		}
	}
	void LSFind(int itr)
	{
		int smallest;
		int largest;
		node* current = root;
		node* current1 = root;
		
		itr--;
		
			while (current != nullptr &&current1!=nullptr &&itr>1)
			{
				if (itr == 0)
				{
					break;
				}
				else
				{
					current = current->left;
					current1 = current1->right;
				}
				itr--;
			}
			smallest = current->left->data;
			largest = current1->right->data;
		cout << "\nsmallest element:" << smallest;
		cout << "\nLargest element:" << largest<<endl;
	}
private:
	void deleteleaf(int data)
	{
		node* current = root;
		node* g_parent = root, * parent = root;
		while (current != nullptr)
		{

			if (current->data == data)
			{
				break;
			}
			else
			{
				g_parent = parent;
				parent = current;
			}
			if (current->data > data)
			{
				current = current->left;
			}
			else
			{
				current = current->right;
			}
		}
		if (current != nullptr)
		{
			bool flag = false;
			if (current->left == nullptr && current->right == nullptr && current == root)
			{
				cout << "\nOnly root Node\nDeleting It\n";
				root = nullptr;
				current = nullptr;
			}
			else if (current->left == nullptr && current->right == nullptr && current != root)
			{
				cout << "\nDeleting a leaf Node\n";

				if (parent->left == nullptr)
				{
					flag = true;
					if (parent->right->data == data)
					{
						parent->right = nullptr;
					}
				}
				else if (parent->right == nullptr)
				{
					flag = true;
					if (parent->left->data == data)
					{
						parent->left = nullptr;
					}

				}
				if (flag != true)
				{
					if (parent->left->data == data)
					{
						parent->left = nullptr;
					}
					else if (parent->right->data == data)
					{
						parent->right = nullptr;
					}
				}
			}
			else if (current->left == nullptr || current->right == nullptr)
			{
				cout << "\nDeleting a node with one child\n";
				if (parent->left == current)
				{
					cout << "\nDeleting Left Child\n";
					if (current->right == nullptr)
					{
						parent->left = current->left;
						//parent = nullptr;
					}
					else
					{
						parent->left = current->right;
						//parent = nullptr;
					}
				}
				else if (parent->right == current)
				{
					cout << "\nDeleting Right CHild\n";
					if (current->right == nullptr)
					{
						parent->right = current->left;
						//parent = nullptr;
					}
					else
					{
						parent->right = current->right;
						//parent = nullptr;
					}
				}


				//if (parent->left->data == data)
				//{
				//	if(current)
				//	g_parent->left = current->left;
				//	//parent= nullptr;
				//}
				//else
				//{
				//	if (current->right == nullptr)
				//	{
				//		g_parent->right = current->left;
				//		parent= nullptr;
				//	}
				//	else
				//	{
				//		g_parent->left = current->right;
				//		parent = nullptr;
				//	}
				//	//parent = nullptr;
				//}
			}
			else if (current->left != nullptr && current->right != nullptr)
			{
				cout << "\nDeleting a node with Two childs\n";
				if (current == root)
				{
					cout << "\nDeleting Root:\n";
					node* current2 = current;
					current2 = current2->left;
					while (current2 != nullptr && current2->right != nullptr)
					{
						current2 = current2->right;
					}

					root = current2;
					current2->right = current->right;
					current2->left = current->left;

					//if (current->left->left != nullptr)
					//{
						//current2->left = current->left;
					//}
					node* current3 = current->left;
					while (current3->right != current2)
					{
						current3 = current3->right;
					}
					current3->right = nullptr;
				}
				else
				{
					node* current2 = current;
					current2 = current2->left;
					while (current2 != nullptr && current2->right != nullptr)
					{
						current2 = current2->right;
					}
					if (parent->left == current)
					{

						parent->left = current2;
						current2->right = current->right;
						if (current->left->left != nullptr)
						{
							current2->left = current2->left;
						}
						else
						{
							current2->left = current->left;
							if (current2->left == current2)
							{
								current2->left = nullptr;
							}
						}
						node* current3 = current->left;
						while (current3 != nullptr && current3->right != current2)
						{
							current3 = current3->right;
						}
						if (current3 != nullptr)
						{
							current3->right = nullptr;
						}
						/*if (current3== current2 && current3== current2)
						{
							current->left->right = nullptr;
						}*/
					}
					else if (parent->right == current)
					{
						cout << "\nparent right data:" << parent->right->data << " " << current2->data << endl;
						parent->right = current2;
						current2->right = current->right;
						if (current->left->left != nullptr)
						{
							current2->left = current2->left;
						}
						else
						{
							current2->left = current->left;
							if (current2->left == current2)
							{
								current2->left = nullptr;
							}
						}
						node* current3 = current->left;
						while (current3 != nullptr && current3->right != current2)
						{
							current3 = current3->right;
						}
						if (current3 != nullptr)
						{
							current3->right = nullptr;
						}
					}
					//current = current2;
					//current2 = nullptr;
				}
			}
			/*else if (current->left == nullptr && current->right == nullptr && current == root)
			{
			 cout << "\ndeltinf\n";
				root = nullptr;
				current = nullptr;
			}*/
		}
	}

public:
	void deletefromrange(int a, int b)
	{
		node* current = root;
		node* current1 = root;
		current = current->left;
		while (current->left != nullptr)
		{	
			current = current->left;
		}
		if (current->data <= a)
		{
			/*current = root;
			current1 = root;*/
			while (a <= b)
			{
				deleteleaf(a);
				++a;
			}
		}
	}
	void inorder()
	{
		node* temp = root;
		if (temp != nullptr)
		{
			in_order(temp);
		}
		else
		{
			cout << "\nNothing Left to Print\n";
		}
	}
private:
	void in_order(node* temp)
	{
		if (temp == nullptr)
		{
			/*cout << "\nhello\n";*/
			return;
		}
		else
		{
			
			//temp = temp->left;
			/*cout << "\nleft\n";*/
			in_order(temp->left);
			/*cout << "\nparent\n";*/
			cout << temp->data << " \n";
			//temp = temp->right;
			/*cout << "\nright\n";*/
			in_order(temp->right);
			
		}
	}
};