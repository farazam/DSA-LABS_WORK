#include<iostream>
#include"BST.h"
using namespace std;
int menu()
{
	cout << "\nPress 1) to count the total number of leaf nodes.\n";
	cout << "\nPress 2) to display total number of non leaf nodes.\n";
	cout << "\nPress 3) to print all paths from root to leaf node.\n";
	cout << "\nPress 0) to exit\n";
	int m;
	cout << endl;
	cin >> m;
	return m;
}
int main()
{
	BST* obj = new BST();
	obj->insert(10);
	obj->insert(8);
	obj->insert(15);
	obj->insert(3);
	obj->insert(9);
	obj->insert(14);
	int m = menu();
	while (m != 0)
	{
		switch (m)
		{
		case 1:
		{
			int c = obj->count();
			cout << "\ntotal leaf nodes:" << c << endl;
			m = menu();
		}break;
		case 2:
		{
			int c = obj->countnonleaf();
			cout << "\ntotal non leaf nodes:" << c<< endl;
			m = menu();
		}break;
		case 3:
		{
			obj->printallpaths();
			m = menu();
		}break;
		case 0:
		{
			cout << "\nProgram Terminated\n";
			m = 0;
		}break;
		default:
		{
			cout << "\nYou Opted Wrong option\n";
		}
		}
	}
	system("pause");
	return 0;
}

	